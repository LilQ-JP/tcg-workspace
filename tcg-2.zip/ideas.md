# TCG Universal Workspace デザインブレインストーミング

## 要件整理
- 汎用カードゲームシミュレーター（対戦機能付き）
- macOSライクな洗練されたUI
- ダークテーマベース（カードゲームの雰囲気に合う）
- 高コントラスト、太字フォント重視
- 商用販売を前提としたプロフェッショナルな仕上がり

---

<response>
<text>
## Idea 1: "Obsidian Table" — ネオ・マテリアルデザイン

**Design Movement:** ネオモーフィズム + マテリアルデザイン3のハイブリッド

**Core Principles:**
1. 深みのある暗色の「テーブル表面」を再現し、カードが浮き上がるような立体感
2. すりガラス（frosted glass）エフェクトによるパネルの階層化
3. 微細なグレインテクスチャで高級感のある質感を演出
4. 操作に対する即座のフィードバック（マイクロインタラクション）

**Color Philosophy:**
- ベース: #0D0D12（漆黒に近い深紫）→ テーブルフェルトの高級感
- サーフェス: #1A1A24（カードゾーンの背景）
- アクセント: #3B82F6（macOS Blue）→ 選択・アクティブ状態
- セカンダリ: #10B981（エメラルド）→ 成功・接続状態
- デストラクティブ: #EF4444 → 削除・切断
- テキスト: #F1F5F9（明るいグレー）→ 高コントラスト

**Layout Paradigm:**
- 3段フレックスレイアウト（上段：相手フィールド / 中段：共有エリア / 下段：自分フィールド）
- 左サイドに折りたたみ可能なコントロールパネル（接続・設定）
- フローティングツールバー（macOS Dockスタイル）

**Signature Elements:**
1. カードにリアルなドロップシャドウ + ホバー時の浮遊アニメーション
2. ゾーン境界にグロウエフェクト（ドラッグ中にアクティブ化）
3. 接続状態を示すパルスインジケーター

**Interaction Philosophy:**
- ドラッグ時にカードが「持ち上がる」（scale + shadow増加）
- ドロップ先のゾーンがハイライト（border-glow）
- 右クリックメニューはmacOSのコンテキストメニュー風

**Animation:**
- カード移動: spring物理（framer-motion）
- メニュー展開: 0.15s ease-out スケールイン
- ゾーン切り替え: 0.2s フェード + スライド
- 接続確立時: パーティクルバースト

**Typography System:**
- 見出し: SF Pro Display (system-ui) / Bold 700
- 本文: SF Pro JP / Medium 500
- カウンター・バッジ: SF Mono / Bold 700
- フォールバック: "Hiragino Kaku Gothic Pro", "メイリオ", sans-serif
</text>
<probability>0.08</probability>
</response>

<response>
<text>
## Idea 2: "Velvet Arena" — シネマティック・ダーク

**Design Movement:** シネマティックUI（映画的インターフェース） + ブルータリズムの要素

**Core Principles:**
1. 映画のHUD（ヘッドアップディスプレイ）のような情報表示
2. 極端なコントラスト（ほぼ黒の背景に鮮やかなアクセント）
3. 幾何学的なグリッドラインがフィールドを構成
4. タイポグラフィ主導のナビゲーション

**Color Philosophy:**
- ベース: #050508（ほぼ真っ黒）→ 映画館の暗闘
- グリッドライン: #1E293B（微かに見えるガイド線）
- プライマリアクセント: #F59E0B（アンバーゴールド）→ カード選択・重要操作
- セカンダリ: #06B6D4（シアン）→ 通信・接続関連
- テキスト: #FFFFFF（純白）→ 最大コントラスト

**Layout Paradigm:**
- フルスクリーンの「アリーナ」ビュー
- 上部に薄いHUDバー（対戦情報・タイマー・接続状態）
- 下部にドック型ツールバー（半透明）
- ゾーンは自由配置可能なフローティングパネル

**Signature Elements:**
1. ゾーン境界に微かなスキャンライン（CRTモニター風）
2. カード操作時のグリッチエフェクト（一瞬のRGBシフト）
3. 対戦相手の操作がゴースト表示（半透明で見える）

**Interaction Philosophy:**
- すべての操作に「重み」を感じさせる（遅延のないが慣性のある動き）
- 重要な操作（シャッフル等）に演出的なアニメーション
- 通信状態をアンビエントライト（画面端の微かな光）で表現

**Animation:**
- カード移動: 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)
- シャッフル: カードが扇形に広がって戻る
- 接続: 画面端からシアンの光が走る
- ターン切り替え: 画面全体の微かなフラッシュ

**Typography System:**
- 見出し: "Helvetica Neue" / Black 900（大文字）
- 本文: system-ui / Bold 600
- HUD数値: "SF Mono", monospace / Bold 700
- 日本語: "Hiragino Kaku Gothic Pro" W6
</text>
<probability>0.05</probability>
</response>

<response>
<text>
## Idea 3: "Slate Workshop" — macOS ネイティブ・ワークスペース

**Design Movement:** Apple Human Interface Guidelines準拠のネイティブアプリ風

**Core Principles:**
1. macOSのFinderやXcodeのような「ツール感」のあるUI
2. サイドバー + メインコンテンツの2カラム構造
3. 控えめだが一貫したアニメーション
4. 情報密度が高いが整理されたレイアウト

**Color Philosophy:**
- ベース: #1C1C1E（macOS Dark Mode標準背景）
- サーフェス: #2C2C2E（カード、パネル）
- セパレーター: #38383A
- アクセント: #0A84FF（macOS System Blue）
- セカンダリ: #30D158（macOS System Green）→ 接続OK
- テキスト: #FFFFFF / #98989D（プライマリ / セカンダリ）

**Layout Paradigm:**
- 左サイドバー: ゾーン一覧・接続パネル・設定（折りたたみ可能）
- メインエリア: 3段分割のカードフィールド（リサイザー付き）
- 右パネル（オプション）: カード詳細・ログ
- 上部: macOS風ツールバー（セグメントコントロール付き）

**Signature Elements:**
1. macOSのウィンドウコントロール（赤黄緑ドット）風のゾーンヘッダー
2. Vibrancy（すりガラス）エフェクトのサイドバーとツールバー
3. SF Symbolsスタイルのアイコン体系

**Interaction Philosophy:**
- macOSの操作感を忠実に再現（ホバーでのハイライト、クリックでの沈み込み）
- コンテキストメニューはmacOS標準に準拠した見た目
- ドラッグ中のスナップガイド表示

**Animation:**
- パネル開閉: 0.25s ease-in-out スライド
- カード移動: 0.2s ease-out トランスレート
- メニュー: 0.15s ease-out フェード + スケール
- 通知: macOS風バナー（上からスライドイン）

**Typography System:**
- 見出し: -apple-system, "SF Pro Display" / Semibold 600
- 本文: -apple-system, "SF Pro JP" / Medium 500
- モノスペース: "SF Mono" / Medium 500
- フォールバック: "Hiragino Kaku Gothic Pro", "メイリオ", Meiryo, sans-serif
</text>
<probability>0.07</probability>
</response>
