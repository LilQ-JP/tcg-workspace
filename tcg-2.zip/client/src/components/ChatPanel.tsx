/**
 * ChatPanel - In-game chat during P2P battles
 * Design: Obsidian Table - slide-in glass panel from right
 */

import { useState, useCallback, useRef, useEffect } from 'react';
import { X, Send } from 'lucide-react';
import type { PeerMessage } from '@/lib/peerManager';

interface PeerState {
  status: string;
  isConnected: boolean;
  isHost: boolean;
  error: string | null;
  messages: PeerMessage[];
  sendChat: (msg: string) => void;
  disconnect: () => void;
}

interface ChatPanelProps {
  peer: PeerState;
  onClose: () => void;
}

interface ChatMessage {
  text: string;
  isMe: boolean;
  timestamp: number;
}

export function ChatPanel({ peer, onClose }: ChatPanelProps) {
  const [input, setInput] = useState('');
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Process incoming chat messages
  useEffect(() => {
    const chatMessages = peer.messages.filter(m => m.type === 'chat');
    const lastMsg = chatMessages[chatMessages.length - 1];
    if (lastMsg) {
      setChatHistory(prev => {
        // Avoid duplicates
        if (prev.length > 0 && prev[prev.length - 1].timestamp === lastMsg.timestamp && !prev[prev.length - 1].isMe) {
          return prev;
        }
        return [...prev, { text: lastMsg.payload, isMe: false, timestamp: lastMsg.timestamp }];
      });
    }
  }, [peer.messages]);

  // Auto-scroll
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [chatHistory]);

  const handleSend = useCallback(() => {
    if (!input.trim()) return;
    peer.sendChat(input.trim());
    setChatHistory(prev => [...prev, { text: input.trim(), isMe: true, timestamp: Date.now() }]);
    setInput('');
  }, [input, peer]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }, [handleSend]);

  return (
    <div className="fixed right-0 top-0 bottom-0 w-[300px] z-[80] glass-strong shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/8">
        <span className="text-sm font-semibold text-foreground">チャット</span>
        <button
          onClick={onClose}
          className="w-6 h-6 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-white/10 transition-colors"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-2">
        {chatHistory.length === 0 && (
          <div className="text-center py-8">
            <p className="text-[10px] text-muted-foreground/40">メッセージはまだありません</p>
          </div>
        )}
        {chatHistory.map((msg, i) => (
          <div key={i} className={`flex ${msg.isMe ? 'justify-end' : 'justify-start'}`}>
            <div className={`
              max-w-[80%] px-3 py-1.5 rounded-lg text-xs
              ${msg.isMe
                ? 'bg-primary/20 text-primary-foreground rounded-br-none'
                : 'bg-white/10 text-foreground rounded-bl-none'
              }
            `}>
              {msg.text}
            </div>
          </div>
        ))}
      </div>

      {/* Input */}
      <div className="p-3 border-t border-white/8">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="メッセージを入力..."
            className="flex-1 px-3 py-2 rounded-lg bg-input border border-border text-xs text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim()}
            className="w-8 h-8 rounded-lg bg-primary/20 text-primary flex items-center justify-center hover:bg-primary/30 disabled:opacity-30 transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
