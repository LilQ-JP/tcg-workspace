/**
 * CardComponent - Individual card rendering
 * Design: Obsidian Table - cards with elevation shadows, glow on selection,
 * smooth rotation transforms, and drag-and-drop support
 * Cards are sized to be clearly visible and recognizable
 */

import { memo } from 'react';
import type { Card } from '@/lib/gameStore';

const CARD_BACK_URL = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663234847362/EU7kgJ5AKrtB2Y6b6KMogq/card-back-pattern-RdyUJYiCPVcDq5aqdhyyyU.webp';

interface CardComponentProps {
  card: Card;
  isSelected: boolean;
  selectionOrder?: number;
  visualFaceDown: boolean;
  showCountBadge?: string;
  faceDownIndex?: number;
  compact?: boolean;
  onDragStart?: (e: React.DragEvent) => void;
  onDrop?: (e: React.DragEvent) => void;
  onClick?: (e: React.MouseEvent) => void;
  onContextMenu?: (e: React.MouseEvent) => void;
}

export const CardComponent = memo(function CardComponent({
  card,
  isSelected,
  selectionOrder,
  visualFaceDown,
  showCountBadge,
  faceDownIndex,
  compact = false,
  onDragStart,
  onDrop,
  onClick,
  onContextMenu,
}: CardComponentProps) {
  // Larger card sizes for better visibility
  const size = compact ? 'w-[48px] h-[67px]' : 'w-[80px] h-[112px]';

  const rotationClass = card.rot === 90
    ? 'rotate-90'
    : card.rot === 180
      ? 'rotate-180'
      : '';

  const hasTopCards = card.topCards && card.topCards.length > 0;
  const hasStack = card.stack && card.stack.length > 0;

  return (
    <div
      data-card
      className={`
        ${size} relative rounded-lg flex-none
        transition-all duration-150 ease-out
        ${rotationClass}
        ${isSelected
          ? 'ring-2 ring-primary shadow-[0_0_16px_oklch(0.62_0.19_260/0.5)] scale-105 z-10'
          : 'hover:scale-[1.04] hover:shadow-xl hover:z-[5]'
        }
        cursor-grab active:cursor-grabbing
      `}
      draggable
      onDragStart={onDragStart}
      onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); }}
      onDrop={onDrop}
      onClick={onClick}
      onContextMenu={onContextMenu}
    >
      {/* Card face or back */}
      <div
        className={`
          w-full h-full rounded-lg overflow-hidden
          ${visualFaceDown
            ? 'border border-slate-600/60'
            : 'border border-white/15'
          }
          shadow-md
        `}
        style={{
          backgroundImage: visualFaceDown
            ? `url(${CARD_BACK_URL})`
            : `url(${card.img})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      {/* Selection order badge */}
      {isSelected && selectionOrder !== undefined && (
        <div className="absolute -top-2 -left-2 w-6 h-6 rounded-full bg-primary text-primary-foreground text-[11px] font-bold flex items-center justify-center shadow-lg z-20 border border-primary-foreground/20">
          {selectionOrder}
        </div>
      )}

      {/* Face-down index badge */}
      {visualFaceDown && faceDownIndex !== undefined && (
        <div className="absolute top-1 right-1 w-5 h-5 rounded-full bg-slate-700/90 text-slate-300 text-[10px] font-bold flex items-center justify-center border border-slate-500/30">
          {faceDownIndex}
        </div>
      )}

      {/* Zone count badge (for deck/grave) */}
      {showCountBadge && (
        <div className="absolute bottom-1 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-black/80 text-white text-[10px] font-bold whitespace-nowrap border border-white/10">
          {showCountBadge}
        </div>
      )}

      {/* Stack badge (under) */}
      {hasStack && (
        <div className="absolute -bottom-1.5 left-0 px-1.5 py-0.5 rounded-md bg-amber-600/90 text-white text-[9px] font-bold whitespace-nowrap shadow-md">
          下: {card.stack.length}枚
        </div>
      )}

      {/* Top cards layer - visual offset to show stacking */}
      {hasTopCards && (
        <>
          <div
            className="absolute inset-0 rounded-lg border border-white/20 pointer-events-none"
            style={{
              backgroundImage: card.topCards[card.topCards.length - 1].faceDown
                ? `url(${CARD_BACK_URL})`
                : `url(${card.topCards[card.topCards.length - 1].img})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              opacity: 0.9,
              transform: 'translate(4px, -4px)',
              zIndex: -1,
            }}
          />
          <div className="absolute -top-1.5 right-0 px-1.5 py-0.5 rounded-md bg-sky-600/90 text-white text-[9px] font-bold whitespace-nowrap shadow-md">
            上: {card.topCards.length}枚
          </div>
        </>
      )}
    </div>
  );
});
