/**
 * ConnectionPanel - P2P connection management panel
 * Design: Obsidian Table - slide-in glass panel from right
 */

import { useState, useCallback } from 'react';
import { toast } from 'sonner';
import { Copy, Wifi, WifiOff, Loader2, X } from 'lucide-react';

interface PeerState {
  status: string;
  isConnected: boolean;
  isHost: boolean;
  error: string | null;
  createRoom: () => Promise<string>;
  joinRoom: (roomId: string) => Promise<void>;
  disconnect: () => void;
}

interface ConnectionPanelProps {
  peer: PeerState;
  onClose: () => void;
}

export function ConnectionPanel({ peer, onClose }: ConnectionPanelProps) {
  const [roomId, setRoomId] = useState('');
  const [createdRoomId, setCreatedRoomId] = useState('');
  const [joinInput, setJoinInput] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [isJoining, setIsJoining] = useState(false);

  const handleCreateRoom = useCallback(async () => {
    setIsCreating(true);
    try {
      const id = await peer.createRoom();
      setCreatedRoomId(id);
      setRoomId(id);
      toast.success(`ルーム作成完了！ ID: ${id}`);
    } catch {
      toast.error('ルームの作成に失敗しました');
    } finally {
      setIsCreating(false);
    }
  }, [peer]);

  const handleJoinRoom = useCallback(async () => {
    if (!joinInput.trim()) {
      toast.error('ルームIDを入力してください');
      return;
    }
    setIsJoining(true);
    try {
      await peer.joinRoom(joinInput.trim().toUpperCase());
      toast.success('対戦相手に接続しました！');
    } catch {
      toast.error('ルームへの接続に失敗しました');
    } finally {
      setIsJoining(false);
    }
  }, [peer, joinInput]);

  const handleCopyId = useCallback(() => {
    navigator.clipboard.writeText(createdRoomId);
    toast.success('ルームIDをコピーしました');
  }, [createdRoomId]);

  const handleDisconnect = useCallback(() => {
    peer.disconnect();
    setCreatedRoomId('');
    setRoomId('');
    toast.info('切断しました');
  }, [peer]);

  const statusColor = {
    disconnected: 'text-muted-foreground',
    connecting: 'text-yellow-400',
    waiting: 'text-amber-400',
    connected: 'text-green-400',
    error: 'text-red-400',
  }[peer.status] || 'text-muted-foreground';

  const statusText = {
    disconnected: '未接続',
    connecting: '接続中...',
    waiting: '対戦相手を待っています...',
    connected: '接続済み',
    error: 'エラー',
  }[peer.status] || '不明';

  return (
    <div className="fixed right-0 top-0 bottom-0 w-[340px] z-[80] glass-strong shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/8">
        <div className="flex items-center gap-2">
          {peer.isConnected ? (
            <Wifi className="w-4 h-4 text-green-400" />
          ) : (
            <WifiOff className="w-4 h-4 text-muted-foreground" />
          )}
          <span className="text-sm font-semibold text-foreground">対戦接続</span>
        </div>
        <button
          onClick={onClose}
          className="w-6 h-6 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-white/10 transition-colors"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Status */}
      <div className="px-4 py-3 border-b border-white/5">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${peer.isConnected ? 'bg-green-400' : peer.status === 'waiting' ? 'bg-amber-400 animate-pulse' : peer.status === 'connecting' ? 'bg-yellow-400 animate-pulse' : 'bg-slate-500'}`} />
          <span className={`text-xs font-medium ${statusColor}`}>{statusText}</span>
        </div>
        {peer.error && (
          <p className="text-[10px] text-red-400 mt-1">{peer.error}</p>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {!peer.isConnected ? (
          <>
            {/* Connection visual */}
            <div className="rounded-lg overflow-hidden mb-4">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663234847362/EU7kgJ5AKrtB2Y6b6KMogq/connection-visual-DddR7gCSiRt8he52BqXRRA.webp"
                alt="P2P Connection"
                className="w-full h-24 object-cover opacity-60"
              />
            </div>

            {/* Create Room */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-foreground/80">ルームを作成</h3>
              <p className="text-[10px] text-muted-foreground">
                ルームを作成して、対戦相手にIDを共有してください。
              </p>
              <button
                onClick={handleCreateRoom}
                disabled={isCreating || peer.status === 'waiting'}
                className="w-full py-2 rounded-lg bg-primary/20 text-primary text-xs font-semibold hover:bg-primary/30 disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
              >
                {isCreating ? <Loader2 className="w-3 h-3 animate-spin" /> : null}
                {peer.status === 'waiting' ? '待機中...' : 'ルームを作成'}
              </button>

              {createdRoomId && (
                <div className="flex items-center gap-2 p-2 rounded-lg bg-white/5 border border-white/10">
                  <span className="text-lg font-mono font-bold text-primary tracking-widest flex-1 text-center">
                    {createdRoomId}
                  </span>
                  <button
                    onClick={handleCopyId}
                    className="p-1.5 rounded-md hover:bg-white/10 text-muted-foreground hover:text-foreground transition-colors"
                    title="コピー"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* Divider */}
            <div className="flex items-center gap-3">
              <div className="flex-1 h-px bg-white/10" />
              <span className="text-[10px] text-muted-foreground/50">または</span>
              <div className="flex-1 h-px bg-white/10" />
            </div>

            {/* Join Room */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-foreground/80">ルームに参加</h3>
              <p className="text-[10px] text-muted-foreground">
                対戦相手から共有されたルームIDを入力してください。
              </p>
              <input
                type="text"
                value={joinInput}
                onChange={(e) => setJoinInput(e.target.value.toUpperCase())}
                placeholder="ルームID (例: ABC123)"
                className="w-full px-3 py-2 rounded-lg bg-input border border-border text-sm font-mono text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:ring-1 focus:ring-primary tracking-widest text-center"
                maxLength={6}
              />
              <button
                onClick={handleJoinRoom}
                disabled={isJoining || !joinInput.trim()}
                className="w-full py-2 rounded-lg bg-white/10 text-foreground text-xs font-semibold hover:bg-white/15 disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
              >
                {isJoining ? <Loader2 className="w-3 h-3 animate-spin" /> : null}
                参加する
              </button>
            </div>

            {/* How it works */}
            <div className="p-3 rounded-lg bg-white/[0.03] border border-white/5 space-y-1.5">
              <h4 className="text-[10px] font-bold text-muted-foreground/70">P2P通信について</h4>
              <p className="text-[9px] text-muted-foreground/50 leading-relaxed">
                WebRTC技術を使用したブラウザ間の直接通信です。サーバーを経由せず、2つのブラウザが直接データをやり取りします。通信内容は暗号化されています。
              </p>
            </div>
          </>
        ) : (
          <>
            {/* Connected state */}
            <div className="text-center space-y-3 py-4">
              <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center mx-auto">
                <Wifi className="w-6 h-6 text-green-400" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">接続済み</p>
                <p className="text-[10px] text-muted-foreground mt-1">
                  {peer.isHost ? 'ホスト (ルーム作成者)' : 'ゲスト (参加者)'}
                </p>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-white/[0.03] border border-white/5 space-y-2">
              <p className="text-[10px] text-muted-foreground/70 leading-relaxed">
                対戦相手と接続されています。お互いのカード操作がリアルタイムで同期されます。
              </p>
              <p className="text-[10px] text-muted-foreground/50 leading-relaxed">
                手札は相手には裏向きで表示されます。
              </p>
            </div>

            <button
              onClick={handleDisconnect}
              className="w-full py-2 rounded-lg bg-destructive/20 text-destructive text-xs font-semibold hover:bg-destructive/30 transition-colors"
            >
              切断する
            </button>
          </>
        )}
      </div>
    </div>
  );
}
