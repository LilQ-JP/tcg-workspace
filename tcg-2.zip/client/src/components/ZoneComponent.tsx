/**
 * ZoneComponent - Card zone container
 * Design: Obsidian Table - glass-bordered zones with glow effects,
 * zone headers, and drag-and-drop targets
 * Improved card layout with better sizing and spacing
 */

import { memo, useState } from 'react';
import { CardComponent } from './CardComponent';
import type { Card, Zone } from '@/lib/gameStore';

interface ZoneComponentProps {
  zone: Zone;
  isHandMasked: boolean;
  selectedCardIds: number[];
  onCardDragStart: (e: React.DragEvent, cardId: number) => void;
  onZoneDrop: (e: React.DragEvent, zone: Zone) => void;
  onCardDrop: (e: React.DragEvent, card: Card, zone: Zone) => void;
  onCardClick: (cardId: number) => void;
  onCardContextMenu: (e: React.MouseEvent, card: Card, zone: Zone) => void;
  onZoneContextMenu: (e: React.MouseEvent, zone: Zone) => void;
}

export const ZoneComponent = memo(function ZoneComponent({
  zone,
  isHandMasked,
  selectedCardIds,
  onCardDragStart,
  onZoneDrop,
  onCardDrop,
  onCardClick,
  onCardContextMenu,
  onZoneContextMenu,
}: ZoneComponentProps) {
  const isDeck = zone.type === 'deck';
  const isGrave = zone.type === 'grave';
  const isHand = zone.id === 'hand';
  const isPlay = zone.id === 'play';
  const [isDragOver, setIsDragOver] = useState(false);

  // For deck/grave, only show top card
  const cardsToRender = (isDeck || isGrave) ? zone.cards.slice(0, 1) : zone.cards;
  let faceDownIndex = 1;

  const zoneTypeIcon = isDeck ? '🂠' : isGrave ? '🪦' : isHand ? '✋' : isPlay ? '⚔️' : '📋';

  return (
    <div
      className={`
        glass rounded-xl overflow-hidden h-full
        ${isPlay ? 'min-h-[100px]' : isHand ? 'min-h-[100px]' : 'min-w-[160px] flex-1'}
        transition-all duration-200
        ${isDragOver ? 'ring-1 ring-primary/40 bg-primary/5' : ''}
      `}
      onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
      onDragLeave={() => setIsDragOver(false)}
      onDrop={(e) => { setIsDragOver(false); onZoneDrop(e, zone); }}
      onContextMenu={(e) => { e.preventDefault(); e.stopPropagation(); onZoneContextMenu(e, zone); }}
    >
      {/* Zone Header */}
      <div className="flex items-center gap-2 px-3 py-2 border-b border-white/5 bg-white/[0.03]">
        <span className="text-xs opacity-60">{zoneTypeIcon}</span>
        <span className="text-xs font-semibold text-foreground/80 tracking-wide">{zone.name}</span>
        <span className="text-[10px] text-muted-foreground ml-auto font-mono tabular-nums">{zone.cards.length}枚</span>
      </div>

      {/* Cards Area */}
      <div className={`
        p-2.5 flex flex-wrap gap-2 items-start content-start
        ${isHand ? 'min-h-[80px]' : 'min-h-[70px]'}
        ${zone.cards.length === 0 ? 'justify-center items-center' : ''}
      `}>
        {zone.cards.length === 0 && (
          <div className="text-[11px] text-muted-foreground/30 italic select-none py-4">
            カードなし
          </div>
        )}
        {cardsToRender.map(card => {
          const isSelected = selectedCardIds.includes(card.id);
          let visualFaceDown = card.faceDown;
          if (isHand && isHandMasked) visualFaceDown = true;

          const currentFaceDownIndex = visualFaceDown && !isDeck ? faceDownIndex++ : undefined;

          return (
            <CardComponent
              key={card.id}
              card={card}
              isSelected={isSelected}
              selectionOrder={isSelected ? selectedCardIds.indexOf(card.id) + 1 : undefined}
              visualFaceDown={visualFaceDown}
              showCountBadge={(isDeck || isGrave) ? `${zone.cards.length}枚` : undefined}
              faceDownIndex={currentFaceDownIndex}
              onDragStart={(e) => onCardDragStart(e, card.id)}
              onDrop={(e) => onCardDrop(e, card, zone)}
              onClick={(e) => { e.stopPropagation(); onCardClick(card.id); }}
              onContextMenu={(e) => { e.preventDefault(); e.stopPropagation(); onCardContextMenu(e, card, zone); }}
            />
          );
        })}
      </div>
    </div>
  );
});
