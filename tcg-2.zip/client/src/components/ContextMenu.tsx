/**
 * ContextMenu - macOS-style right-click context menu
 * Design: Obsidian Table - frosted glass with subtle borders
 */

import { useEffect, useRef } from 'react';
import type { MenuItem } from './GameBoard';

interface ContextMenuProps {
  x: number;
  y: number;
  items: MenuItem[];
  onClose: () => void;
}

export function ContextMenu({ x, y, items, onClose }: ContextMenuProps) {
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = menuRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    if (x + rect.width > window.innerWidth) {
      el.style.left = `${window.innerWidth - rect.width - 8}px`;
    }
    if (y + rect.height > window.innerHeight) {
      el.style.top = `${window.innerHeight - rect.height - 8}px`;
    }
  }, [x, y]);

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-[9998]"
        onClick={onClose}
        onContextMenu={(e) => { e.preventDefault(); onClose(); }}
      />
      {/* Menu */}
      <div
        ref={menuRef}
        data-menu
        className="fixed z-[9999] glass-strong rounded-lg shadow-2xl py-1.5 min-w-[200px] max-w-[320px] max-h-[80vh] overflow-y-auto animate-in fade-in-0 zoom-in-95 duration-100"
        style={{ left: x, top: y }}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-1 right-1 w-5 h-5 rounded-full flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-white/10 text-xs transition-colors"
        >
          ×
        </button>

        {items.map((item, i) => {
          if (item.type === 'divider') {
            return <div key={i} className="h-px bg-white/8 my-1 mx-2" />;
          }
          if (item.type === 'group') {
            return (
              <div key={i} className="px-3 py-1 text-[10px] font-bold text-muted-foreground/60 uppercase tracking-wider select-none">
                {item.label}
              </div>
            );
          }
          return (
            <button
              key={i}
              className="w-full text-left px-3 py-1.5 text-xs text-foreground/90 hover:bg-primary/20 hover:text-primary-foreground transition-colors flex items-center gap-2"
              onClick={() => item.action()}
            >
              {item.label}
            </button>
          );
        })}
      </div>
    </>
  );
}
