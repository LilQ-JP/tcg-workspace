/**
 * Toolbar - macOS Dock-style floating toolbar
 * Design: Obsidian Table - frosted glass dock at bottom center
 * with icon buttons and labels for all game actions
 */

import { useRef, useCallback, useState } from 'react';
import { useGameActions } from '@/hooks/useGameStore';
import { toast } from 'sonner';
import {
  Upload,
  Play,
  Undo2,
  Shuffle,
  Hand,
  Plus,
  Wifi,
  WifiOff,
  MessageCircle,
  Dice5,
  Eye,
  EyeOff,
  RotateCcw,
} from 'lucide-react';

interface ToolbarProps {
  isConnected: boolean;
  onToggleConnection: () => void;
  onToggleChat: () => void;
}

export function Toolbar({ isConnected, onToggleConnection, onToggleChat }: ToolbarProps) {
  const actions = useGameActions();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isHandMasked, setIsHandMasked] = useState(false);

  const handleLoadImages = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    const promises = files.map(f => new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onload = (ev) => resolve(ev.target!.result as string);
      reader.readAsDataURL(f);
    }));

    Promise.all(promises).then(images => {
      actions.setPool(images);
      toast.success(`${images.length}枚の画像を読み込みました`);
    });

    // Reset input so same files can be loaded again
    e.target.value = '';
  }, [actions]);

  const handleInitGame = useCallback(() => {
    if (!actions.initGame()) {
      toast.error('先に画像を読み込んでください');
      return;
    }
    toast.success('ゲームを開始しました！山札をシャッフル済み');
  }, [actions]);

  const handleDraw = useCallback(() => {
    const count = prompt('何枚引きますか？', '1');
    if (count) {
      const n = parseInt(count);
      if (!isNaN(n) && n > 0) {
        if (!actions.drawCards(n)) {
          toast.error('山札の枚数が足りません！');
        }
      }
    }
  }, [actions]);

  const handleShuffle = useCallback(() => {
    actions.shuffleDeck();
    toast.success('山札をシャッフルしました');
  }, [actions]);

  const handleAddZone = useCallback(() => {
    const name = prompt('新しいエリアの名前を入力してください', '新エリア');
    if (name) {
      actions.addZone(name);
      toast.success(`「${name}」エリアを追加しました`);
    }
  }, [actions]);

  const handleToggleMask = useCallback(() => {
    actions.toggleHandMask();
    setIsHandMasked(prev => !prev);
  }, [actions]);

  const handleRandom = useCallback(() => {
    const result = actions.discardRandomHand();
    if (!result) {
      toast.error('手札がありません！');
    } else {
      toast.info('手札からランダムに1枚を待機エリアへ移動しました');
    }
  }, [actions]);

  const handleReset = useCallback(() => {
    if (confirm('ゲームをリセットしますか？すべてのカードが消去されます。')) {
      actions.reset();
      toast.info('ゲームをリセットしました');
    }
  }, [actions]);

  const buttons = [
    { icon: Upload, label: '読込', action: handleLoadImages, accent: false },
    { icon: Play, label: '開始', action: handleInitGame, accent: true },
    { icon: Hand, label: 'ドロー', action: handleDraw, accent: false },
    { icon: Shuffle, label: 'シャッフル', action: handleShuffle, accent: false },
    { icon: Undo2, label: '戻す', action: () => actions.undo(), accent: false },
    { icon: isHandMasked ? Eye : EyeOff, label: 'マスク', action: handleToggleMask, accent: false },
    { icon: Dice5, label: 'ランダム', action: handleRandom, accent: false },
    { icon: Plus, label: 'エリア+', action: handleAddZone, accent: false },
    { icon: RotateCcw, label: 'リセット', action: handleReset, accent: false },
    { divider: true },
    { icon: isConnected ? Wifi : WifiOff, label: '対戦', action: onToggleConnection, accent: isConnected },
    ...(isConnected ? [{ icon: MessageCircle, label: 'チャット', action: onToggleChat, accent: false }] : []),
  ];

  return (
    <div data-toolbar className="fixed bottom-3 left-1/2 -translate-x-1/2 z-50">
      <div className="glass-strong rounded-2xl px-3 py-2 flex items-center gap-1 shadow-2xl shadow-black/50">
        {buttons.map((btn, i) => {
          if ('divider' in btn) {
            return <div key={i} className="w-px h-10 bg-white/10 mx-1" />;
          }
          const Icon = btn.icon!;
          return (
            <button
              key={i}
              onClick={btn.action}
              className={`
                group relative flex flex-col items-center justify-center gap-0.5
                px-2 py-1.5 rounded-xl transition-all duration-200
                ${btn.accent
                  ? 'bg-primary/20 text-primary hover:bg-primary/30'
                  : 'text-muted-foreground hover:text-foreground hover:bg-white/10'
                }
              `}
              title={btn.label}
            >
              <Icon className="w-4 h-4" strokeWidth={2} />
              <span className="text-[8px] font-medium leading-none opacity-70 group-hover:opacity-100 transition-opacity">
                {btn.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="image/*"
        className="hidden"
        onChange={handleFileChange}
      />
    </div>
  );
}
