/**
 * GameBoard - Main card playing field
 * Design: Obsidian Table - 3 row layout (play area, middle zones, hand)
 * with dark felt texture, zone glow effects, and card drag-and-drop
 * Bottom padding accounts for the floating toolbar dock
 */

import { useRef, useState, useCallback } from 'react';
import { useGameStore, useGameActions } from '@/hooks/useGameStore';
import { ZoneComponent } from './ZoneComponent';
import { ContextMenu } from './ContextMenu';
import { CardModal } from './CardModal';
import { CardPreview } from './CardPreview';
import type { Card, Zone } from '@/lib/gameStore';

interface MenuState {
  x: number;
  y: number;
  items: MenuItem[];
}

export interface MenuItem {
  label: string;
  action: () => void;
  type?: 'item' | 'group' | 'divider';
}

export function GameBoard() {
  const state = useGameStore();
  const actions = useGameActions();
  const [contextMenu, setContextMenu] = useState<MenuState | null>(null);
  const [modalState, setModalState] = useState<{
    mode: 'zone' | 'stack' | 'peek';
    zone?: Zone;
    card?: Card;
  } | null>(null);
  const [previewImg, setPreviewImg] = useState<string | null>(null);
  const boardRef = useRef<HTMLDivElement>(null);

  const closeMenu = useCallback(() => setContextMenu(null), []);

  const showMenu = useCallback((e: React.MouseEvent, items: MenuItem[]) => {
    e.preventDefault();
    e.stopPropagation();
    setContextMenu({ x: e.clientX, y: e.clientY, items });
  }, []);

  // --- Zone context menu ---
  const handleZoneMenu = useCallback((e: React.MouseEvent, zone: Zone) => {
    const items: MenuItem[] = [];

    if (state.selectedCardIds.length > 0) {
      items.push({
        label: `選択中の ${state.selectedCardIds.length} 枚をここに移動`,
        action: () => { actions.moveSelectedCards(zone.id); closeMenu(); },
      });
      items.push({ label: '', action: () => {}, type: 'divider' });
    }

    if (zone.id === 'hand') {
      items.push({
        label: state.isHandMasked ? '手札を見る (マスク解除)' : '手札を隠す (マスク)',
        action: () => { actions.toggleHandMask(); closeMenu(); },
      });
      if (zone.cards.length > 0) {
        items.push({ label: '', action: () => {}, type: 'divider' });
        items.push({
          label: '手札からランダムに1枚選ぶ',
          action: () => { actions.selectRandomHandCard(); closeMenu(); },
        });
      }
      items.push({ label: '', action: () => {}, type: 'divider' });
    }

    items.push({ label: 'エリア操作', action: () => {}, type: 'group' });

    if (zone.type === 'deck') {
      items.push({
        label: 'シャッフル',
        action: () => { actions.shuffleDeck(zone.id); closeMenu(); },
      });
      items.push({
        label: '指定枚数引く (手札へ)',
        action: () => {
          const count = prompt('何枚引きますか？', '1');
          if (count) {
            const n = parseInt(count);
            if (!isNaN(n) && n > 0) {
              if (!actions.drawCards(n)) alert('山札の枚数が足りません！');
            }
          }
          closeMenu();
        },
      });
      items.push({
        label: '上から指定枚数を見る',
        action: () => {
          const count = prompt('上から何枚見ますか？', '3');
          if (count) {
            const n = parseInt(count);
            if (!isNaN(n) && n > 0) {
              const cards = actions.lookAtTopCards(zone.id, n);
              if (cards) {
                setModalState({ mode: 'peek', zone });
              } else {
                alert('山札の枚数が足りません！');
              }
            }
          }
          closeMenu();
        },
      });
    }

    if (zone.type === 'deck' || zone.type === 'grave') {
      items.push({
        label: '中身を一覧表示',
        action: () => { setModalState({ mode: 'zone', zone }); closeMenu(); },
      });
    }

    if (!zone.isFixed) {
      items.push({ label: '', action: () => {}, type: 'divider' });
      items.push({ label: 'エリア管理', action: () => {}, type: 'group' });
      items.push({
        label: '名称変更',
        action: () => {
          const newName = prompt('新しいエリア名を入力してください', zone.name);
          if (newName) actions.renameZone(zone.id, newName);
          closeMenu();
        },
      });
      items.push({
        label: 'このエリアを削除',
        action: () => {
          if (zone.cards.length > 0) {
            if (!confirm(`「${zone.name}」にはカードがあります。削除しますか？`)) return;
          }
          actions.removeZone(zone.id);
          closeMenu();
        },
      });
    }

    showMenu(e, items);
  }, [state.selectedCardIds, state.isHandMasked, actions, showMenu, closeMenu]);

  // --- Card context menu ---
  const handleCardMenu = useCallback((e: React.MouseEvent, card: Card, zone: Zone) => {
    if (zone.type === 'deck' || zone.type === 'grave') {
      handleZoneMenu(e, zone);
      return;
    }

    const items: MenuItem[] = [];
    const isMulti = state.selectedCardIds.includes(card.id) && state.selectedCardIds.length > 1;
    const targetIds = isMulti ? state.selectedCardIds : [card.id];

    if (!card.faceDown && !isMulti) {
      items.push({
        label: '画像を大きく表示',
        action: () => { setPreviewImg(card.img); closeMenu(); },
      });
      items.push({ label: '', action: () => {}, type: 'divider' });
    }

    items.push({ label: isMulti ? `向きの変更 (${targetIds.length}枚)` : '向きの変更', action: () => {}, type: 'group' });
    items.push({ label: '縦向き (0°)', action: () => { actions.setMultipleRotation(targetIds, 0); closeMenu(); } });
    items.push({ label: '横向き (90°)', action: () => { actions.setMultipleRotation(targetIds, 90); closeMenu(); } });
    items.push({ label: '逆向き (180°)', action: () => { actions.setMultipleRotation(targetIds, 180); closeMenu(); } });

    items.push({ label: '', action: () => {}, type: 'divider' });
    items.push({ label: '表裏の変更', action: () => {}, type: 'group' });
    items.push({
      label: '表裏を切り替え',
      action: () => { actions.toggleMultipleFaces(targetIds); closeMenu(); },
    });

    if ((card.stack && card.stack.length > 0) || (card.topCards && card.topCards.length > 0)) {
      if (!isMulti) {
        items.push({ label: '', action: () => {}, type: 'divider' });
        items.push({
          label: '重なっているカードを一覧表示',
          action: () => { setModalState({ mode: 'stack', card }); closeMenu(); },
        });
      }
    }

    if (card.topCards && card.topCards.length > 0) {
      items.push({ label: '', action: () => {}, type: 'divider' });
      items.push({ label: '上に重なっているカード', action: () => {}, type: 'group' });
      items.push({
        label: '一番上のカードを外す【捨て札へ】',
        action: () => { targetIds.forEach(id => actions.removeTopCardToZone(id, 'grave')); closeMenu(); },
      });
      items.push({
        label: '一番上のカードを外す【待機エリアへ】',
        action: () => { targetIds.forEach(id => actions.removeTopCardToZone(id, 'wait')); closeMenu(); },
      });
    }

    items.push({ label: '', action: () => {}, type: 'divider' });
    items.push({ label: isMulti ? `移動 (${targetIds.length}枚)` : '移動', action: () => {}, type: 'group' });

    // Add all zones as move targets
    state.zones.forEach(z => {
      if (z.id === zone.id) return; // Skip current zone
      items.push({
        label: `${z.name}へ`,
        action: () => {
          if (isMulti) {
            actions.moveSelectedCards(z.id);
          } else {
            actions.moveCardToZone(card.id, z.id);
          }
          closeMenu();
        },
      });
    });

    showMenu(e, items);
  }, [state.selectedCardIds, state.zones, actions, showMenu, closeMenu, handleZoneMenu]);

  // --- Drag & Drop ---
  const handleCardDragStart = useCallback((e: React.DragEvent, cardId: number) => {
    e.dataTransfer.setData('text/plain', cardId.toString());
  }, []);

  const handleZoneDrop = useCallback((e: React.DragEvent, zone: Zone) => {
    e.preventDefault();
    const draggedId = parseInt(e.dataTransfer.getData('text/plain'));
    if (isNaN(draggedId)) return;

    if (zone.type === 'deck') {
      const items: MenuItem[] = [
        { label: '山札の上下に置く', action: () => {}, type: 'group' },
        { label: '一番上に置く (裏向き)', action: () => { actions.moveToDeckEdge(draggedId, zone.id, 'top', true); closeMenu(); } },
        { label: '一番上に置く (表向き)', action: () => { actions.moveToDeckEdge(draggedId, zone.id, 'top', false); closeMenu(); } },
        { label: '一番下に置く (裏向き)', action: () => { actions.moveToDeckEdge(draggedId, zone.id, 'bottom', true); closeMenu(); } },
        { label: '一番下に置く (表向き)', action: () => { actions.moveToDeckEdge(draggedId, zone.id, 'bottom', false); closeMenu(); } },
      ];
      setContextMenu({ x: e.clientX, y: e.clientY, items });
      return;
    }

    if (state.selectedCardIds.includes(draggedId) && state.selectedCardIds.length > 1) {
      actions.moveSelectedCards(zone.id);
    } else {
      actions.moveCardToZone(draggedId, zone.id);
    }
  }, [state.selectedCardIds, actions, closeMenu]);

  const handleCardDrop = useCallback((e: React.DragEvent, targetCard: Card, zone: Zone) => {
    e.preventDefault();
    e.stopPropagation();
    const draggedId = parseInt(e.dataTransfer.getData('text/plain'));
    if (isNaN(draggedId) || draggedId === targetCard.id) return;

    if (zone.type === 'deck') {
      const items: MenuItem[] = [
        { label: '山札の上下に置く', action: () => {}, type: 'group' },
        { label: '一番上に置く (裏向き)', action: () => { actions.moveToDeckEdge(draggedId, zone.id, 'top', true); closeMenu(); } },
        { label: '一番上に置く (表向き)', action: () => { actions.moveToDeckEdge(draggedId, zone.id, 'top', false); closeMenu(); } },
        { label: '一番下に置く (裏向き)', action: () => { actions.moveToDeckEdge(draggedId, zone.id, 'bottom', true); closeMenu(); } },
        { label: '一番下に置く (表向き)', action: () => { actions.moveToDeckEdge(draggedId, zone.id, 'bottom', false); closeMenu(); } },
      ];
      setContextMenu({ x: e.clientX, y: e.clientY, items });
      return;
    }

    // Show stacking options
    const items: MenuItem[] = [
      { label: '重ねる処理の選択', action: () => {}, type: 'group' },
      { label: '表向きで「下」に置く', action: () => { actions.applyDropStack(draggedId, targetCard.id, 'under', false); closeMenu(); } },
      { label: '裏向きで「下」に置く', action: () => { actions.applyDropStack(draggedId, targetCard.id, 'under', true); closeMenu(); } },
      { label: '表向きで「上」に置く', action: () => { actions.applyDropStack(draggedId, targetCard.id, 'top', false); closeMenu(); } },
      { label: '裏向きで「上」に置く', action: () => { actions.applyDropStack(draggedId, targetCard.id, 'top', true); closeMenu(); } },
    ];
    setContextMenu({ x: e.clientX, y: e.clientY, items });
  }, [actions, closeMenu]);

  // --- Click outside to close menu and deselect ---
  const handleBoardClick = useCallback((e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    if (!target.closest('[data-card]') && !target.closest('[data-menu]') && !target.closest('[data-toolbar]') && !target.closest('[data-modal]')) {
      actions.clearSelection();
    }
    if (!target.closest('[data-menu]')) {
      closeMenu();
    }
  }, [actions, closeMenu]);

  // Categorize zones
  const playZone = state.zones.find(z => z.id === 'play');
  const handZone = state.zones.find(z => z.id === 'hand');
  const middleZones = state.zones.filter(z => z.id !== 'play' && z.id !== 'hand');

  return (
    <div
      ref={boardRef}
      className="h-full w-full flex flex-col relative"
      onClick={handleBoardClick}
      onContextMenu={(e) => e.preventDefault()}
    >
      {/* Play Area (Top) - takes most space */}
      {playZone && (
        <div className="flex-[2] min-h-[100px] p-2 overflow-auto">
          <ZoneComponent
            zone={playZone}
            isHandMasked={state.isHandMasked}
            selectedCardIds={state.selectedCardIds}
            onCardDragStart={handleCardDragStart}
            onZoneDrop={handleZoneDrop}
            onCardDrop={handleCardDrop}
            onCardClick={(cardId) => actions.toggleSelection(cardId)}
            onCardContextMenu={handleCardMenu}
            onZoneContextMenu={handleZoneMenu}
          />
        </div>
      )}

      {/* Divider with subtle glow */}
      <div className="h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent flex-none" />

      {/* Middle Zones (deck, grave, wait, custom) */}
      <div className="flex-[1.5] min-h-[100px] p-2 overflow-auto">
        <div className="flex flex-wrap gap-2 h-full">
          {middleZones.map(zone => (
            <ZoneComponent
              key={zone.id}
              zone={zone}
              isHandMasked={state.isHandMasked}
              selectedCardIds={state.selectedCardIds}
              onCardDragStart={handleCardDragStart}
              onZoneDrop={handleZoneDrop}
              onCardDrop={handleCardDrop}
              onCardClick={(cardId) => actions.toggleSelection(cardId)}
              onCardContextMenu={handleCardMenu}
              onZoneContextMenu={handleZoneMenu}
            />
          ))}
        </div>
      </div>

      {/* Divider */}
      <div className="h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent flex-none" />

      {/* Hand (Bottom) - with extra bottom padding for the floating toolbar */}
      {handZone && (
        <div className="flex-none min-h-[120px] max-h-[35vh] p-2 pb-16 overflow-auto">
          <ZoneComponent
            zone={handZone}
            isHandMasked={state.isHandMasked}
            selectedCardIds={state.selectedCardIds}
            onCardDragStart={handleCardDragStart}
            onZoneDrop={handleZoneDrop}
            onCardDrop={handleCardDrop}
            onCardClick={(cardId) => actions.toggleSelection(cardId)}
            onCardContextMenu={handleCardMenu}
            onZoneContextMenu={handleZoneMenu}
          />
        </div>
      )}

      {/* Context Menu */}
      {contextMenu && (
        <ContextMenu
          x={contextMenu.x}
          y={contextMenu.y}
          items={contextMenu.items}
          onClose={closeMenu}
        />
      )}

      {/* Card Modal */}
      {modalState && (
        <CardModal
          mode={modalState.mode}
          zone={modalState.zone}
          card={modalState.card}
          onClose={() => setModalState(null)}
          onPreview={(img) => setPreviewImg(img)}
        />
      )}

      {/* Card Preview */}
      {previewImg && (
        <CardPreview
          imgSrc={previewImg}
          onClose={() => setPreviewImg(null)}
        />
      )}
    </div>
  );
}
