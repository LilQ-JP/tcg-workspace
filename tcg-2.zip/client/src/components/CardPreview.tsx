/**
 * CardPreview - Enlarged card image overlay
 * Design: Obsidian Table - draggable popup with blur backdrop
 */

import { useRef, useState, useEffect, useCallback } from 'react';

interface CardPreviewProps {
  imgSrc: string;
  onClose: () => void;
}

export function CardPreview({ imgSrc, onClose }: CardPreviewProps) {
  const popupRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const dragOffset = useRef({ x: 0, y: 0 });

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if ((e.target as HTMLElement).tagName === 'IMG' || (e.target as HTMLElement).closest('button')) return;
    setIsDragging(true);
    const rect = popupRef.current!.getBoundingClientRect();
    dragOffset.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
  }, []);

  useEffect(() => {
    if (!isDragging) return;
    const onMove = (e: MouseEvent) => {
      if (!popupRef.current) return;
      popupRef.current.style.left = `${e.clientX - dragOffset.current.x}px`;
      popupRef.current.style.top = `${e.clientY - dragOffset.current.y}px`;
      popupRef.current.style.transform = 'none';
    };
    const onUp = () => setIsDragging(false);
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    return () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
  }, [isDragging]);

  return (
    <>
      <div className="fixed inset-0 z-[200] bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div
        ref={popupRef}
        className="fixed z-[201] glass-strong rounded-xl shadow-2xl p-2 cursor-grab active:cursor-grabbing"
        style={{
          left: '50%',
          top: '50%',
          transform: 'translate(-50%, -50%)',
          maxWidth: 'min(88vw, 500px)',
        }}
        onMouseDown={handleMouseDown}
      >
        <button
          onClick={onClose}
          className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-red-500 text-white text-xs font-bold flex items-center justify-center hover:bg-red-400 transition-colors shadow-lg z-10"
        >
          ×
        </button>
        <img
          src={imgSrc}
          alt="Card Preview"
          className="w-full rounded-lg"
          draggable={false}
        />
      </div>
    </>
  );
}
