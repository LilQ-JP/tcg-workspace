/**
 * CardModal - Draggable modal for viewing zone contents and card stacks
 * Design: Obsidian Table - glass panel, draggable header
 */

import { useState, useRef, useCallback, useEffect } from 'react';
import { useGameStore, useGameActions } from '@/hooks/useGameStore';
import { CardComponent } from './CardComponent';
import type { Card, Zone } from '@/lib/gameStore';
import { gameStore } from '@/lib/gameStore';

interface CardModalProps {
  mode: 'zone' | 'stack' | 'peek';
  zone?: Zone;
  card?: Card;
  onClose: () => void;
  onPreview: (img: string) => void;
}

export function CardModal({ mode, zone, card, onClose, onPreview }: CardModalProps) {
  const state = useGameStore();
  const actions = useGameActions();
  const modalRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const dragOffset = useRef({ x: 0, y: 0 });

  // Draggable header
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('button')) return;
    setIsDragging(true);
    const rect = modalRef.current!.getBoundingClientRect();
    dragOffset.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
  }, []);

  useEffect(() => {
    if (!isDragging) return;
    const onMove = (e: MouseEvent) => {
      if (!modalRef.current) return;
      modalRef.current.style.left = `${e.clientX - dragOffset.current.x}px`;
      modalRef.current.style.top = `${e.clientY - dragOffset.current.y}px`;
      modalRef.current.style.right = 'auto';
    };
    const onUp = () => setIsDragging(false);
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
    return () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
  }, [isDragging]);

  const handleClose = useCallback(() => {
    // Return modal wait cards
    if (state.modalWaitCards.length > 0) {
      if ((mode === 'zone' || mode === 'peek') && zone) {
        gameStore.returnModalWaitCards(zone.id);
      } else {
        gameStore.returnModalWaitCards('wait');
      }
    }
    actions.clearSelection();
    onClose();
  }, [state.modalWaitCards, mode, zone, actions, onClose]);

  const handleShuffle = useCallback(() => {
    if ((mode === 'zone' || mode === 'peek') && zone && zone.type === 'deck') {
      if (state.modalWaitCards.length > 0) {
        gameStore.returnModalWaitCards(zone.id);
      }
      actions.shuffleDeck(zone.id);
    }
    onClose();
  }, [mode, zone, state.modalWaitCards, actions, onClose]);

  // Get cards to display in main area
  let mainCards: { card: Card; isMain: boolean; label: string }[] = [];
  if (mode === 'zone' && zone) {
    mainCards = zone.cards.map(c => ({ card: c, isMain: false, label: '' }));
  } else if (mode === 'stack' && card) {
    const tops = [...(card.topCards || [])].reverse();
    tops.forEach((c, i) => mainCards.push({ card: c, isMain: false, label: `上: ${i + 1}枚目` }));
    mainCards.push({ card, isMain: true, label: 'メイン' });
    (card.stack || []).forEach((c, i) => mainCards.push({ card: c, isMain: false, label: `下: ${i + 1}枚目` }));
  }

  const title = mode === 'peek'
    ? `${zone?.name} の上からめくったカード`
    : mode === 'zone'
      ? `${zone?.name} の中身 (${zone?.cards.length}枚)`
      : '重なっているカード一覧';

  return (
    <div
      ref={modalRef}
      data-modal
      className="fixed z-[100] glass-strong rounded-xl shadow-2xl flex flex-col max-w-[600px] w-[90vw] max-h-[80vh]"
      style={{ right: '20px', top: '60px' }}
    >
      {/* Draggable Header */}
      <div
        className="flex items-center gap-2 px-4 py-2.5 border-b border-white/8 cursor-grab active:cursor-grabbing select-none"
        onMouseDown={handleMouseDown}
      >
        <div className="flex gap-1.5">
          <button
            onClick={handleClose}
            className="w-3 h-3 rounded-full bg-red-500 hover:bg-red-400 transition-colors"
            title="閉じる"
          />
          <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
          <div className="w-3 h-3 rounded-full bg-green-500/50" />
        </div>
        <span className="text-xs font-semibold text-foreground/80 ml-2">{title}</span>
      </div>

      {/* Main Content */}
      {mode !== 'peek' && (
        <div className="p-3 flex flex-wrap gap-2 overflow-y-auto max-h-[30vh] border-b border-white/5">
          {mainCards.length === 0 && (
            <div className="text-xs text-muted-foreground/50 italic w-full text-center py-4">カードなし</div>
          )}
          {mainCards.map(({ card: c, isMain, label }) => (
            <div key={c.id} className="flex flex-col items-center gap-1">
              <div className={isMain ? 'ring-2 ring-yellow-400/60 rounded-md' : ''}>
                <CardComponent
                  card={c}
                  isSelected={state.selectedCardIds.includes(c.id)}
                  selectionOrder={state.selectedCardIds.includes(c.id) ? state.selectedCardIds.indexOf(c.id) + 1 : undefined}
                  visualFaceDown={mode === 'zone' ? false : c.faceDown}
                  compact
                  onClick={(e) => {
                    e.stopPropagation();
                    if (isMain) return;
                    actions.toggleSelection(c.id);
                  }}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    if (!c.faceDown || mode === 'zone') onPreview(c.img);
                  }}
                />
              </div>
              {label && <span className="text-[8px] text-muted-foreground bg-black/50 px-1 rounded">{label}</span>}
            </div>
          ))}
        </div>
      )}

      {/* Wait Area */}
      <div className="p-3">
        <div className="text-[10px] text-muted-foreground/60 font-bold mb-2">
          {mode === 'peek' ? 'めくったカード' : '一時待機エリア'}
        </div>
        <div className="flex flex-wrap gap-2 min-h-[60px] p-2 rounded-lg border border-dashed border-white/10 bg-white/[0.02]">
          {state.modalWaitCards.length === 0 && (
            <div className="text-[10px] text-muted-foreground/30 italic w-full text-center py-2">カードなし</div>
          )}
          {state.modalWaitCards.map(c => (
            <CardComponent
              key={c.id}
              card={c}
              isSelected={state.selectedCardIds.includes(c.id)}
              selectionOrder={state.selectedCardIds.includes(c.id) ? state.selectedCardIds.indexOf(c.id) + 1 : undefined}
              visualFaceDown={(mode === 'peek' || (mode === 'zone' && zone?.type === 'deck')) ? false : c.faceDown}
              compact
              onClick={(e) => { e.stopPropagation(); actions.toggleSelection(c.id); }}
              onContextMenu={(e) => {
                e.preventDefault();
                e.stopPropagation();
                if (!c.faceDown || mode === 'zone' || mode === 'peek') onPreview(c.img);
              }}
            />
          ))}
        </div>
      </div>

      {/* Field Zones Drop Targets */}
      <div className="px-3 pb-2">
        <div className="text-[10px] text-muted-foreground/60 font-bold mb-1.5">盤面エリアへ移動</div>
        <div className="flex flex-wrap gap-1.5">
          {state.zones.map(z => (
            <button
              key={z.id}
              className="px-2.5 py-1.5 rounded-md border border-dashed border-white/15 bg-white/[0.04] text-[10px] text-muted-foreground hover:bg-primary/20 hover:border-primary/40 hover:text-primary-foreground transition-colors"
              onClick={() => {
                if (state.selectedCardIds.length > 0) {
                  actions.moveSelectedCards(z.id);
                }
              }}
            >
              {z.name} ({z.cards.length})
            </button>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-2 p-3 border-t border-white/8">
        <button
          onClick={handleClose}
          className="px-3 py-1.5 rounded-md bg-white/10 text-xs font-medium text-foreground/80 hover:bg-white/15 transition-colors"
        >
          閉じる
        </button>
        {(mode === 'zone' || mode === 'peek') && zone?.type === 'deck' && (
          <button
            onClick={handleShuffle}
            className="px-3 py-1.5 rounded-md bg-primary/20 text-xs font-medium text-primary hover:bg-primary/30 transition-colors"
          >
            {mode === 'peek' ? '残りを戻してシャッフル' : 'シャッフルして閉じる'}
          </button>
        )}
        {state.selectedCardIds.length > 0 && (
          <button
            onClick={() => {
              actions.moveSelectedCards('wait');
              actions.clearSelection();
            }}
            className="px-3 py-1.5 rounded-md bg-green-600/20 text-xs font-medium text-green-400 hover:bg-green-600/30 transition-colors"
          >
            選択中の {state.selectedCardIds.length} 枚を待機エリアへ
          </button>
        )}
      </div>
    </div>
  );
}
