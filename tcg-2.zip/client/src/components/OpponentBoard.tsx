/**
 * OpponentBoard - Read-only view of opponent's game state
 * Design: Obsidian Table - compact red-tinted theme to distinguish from player's board
 * Receives state via P2P messages, opponent's hand is always face-down
 */

import { useEffect, useState, useMemo } from 'react';
import type { Zone } from '@/lib/gameStore';
import type { PeerMessage } from '@/lib/peerManager';

const CARD_BACK_URL = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663234847362/EU7kgJ5AKrtB2Y6b6KMogq/card-back-pattern-RdyUJYiCPVcDq5aqdhyyyU.webp';

interface OpponentBoardProps {
  messages: PeerMessage[];
}

interface OpponentState {
  zones: Zone[];
  isHandMasked: boolean;
}

export function OpponentBoard({ messages }: OpponentBoardProps) {
  const [opponentState, setOpponentState] = useState<OpponentState | null>(null);

  useEffect(() => {
    const lastSync = [...messages].reverse().find(m => m.type === 'state-sync');
    if (lastSync) {
      try {
        const parsed = JSON.parse(lastSync.payload);
        setOpponentState(parsed);
      } catch { /* ignore */ }
    }
  }, [messages]);

  const zones = useMemo(() => opponentState?.zones || [], [opponentState]);

  if (!opponentState) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center">
          <div className="text-sm text-muted-foreground/60 mb-1">対戦相手のフィールド</div>
          <div className="text-xs text-muted-foreground/40">相手のゲーム状態を待機中...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col p-2 gap-1 bg-gradient-to-b from-red-950/10 to-transparent">
      {/* Header */}
      <div className="flex items-center gap-2 px-2 py-1">
        <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
        <span className="text-[11px] font-semibold text-red-400/80 tracking-wider uppercase">
          Opponent Field
        </span>
      </div>

      {/* Zones in a horizontal layout */}
      <div className="flex-1 flex gap-1.5 overflow-x-auto overflow-y-hidden">
        {zones.map(zone => {
          const isDeck = zone.type === 'deck';
          const isGrave = zone.type === 'grave';
          const isHand = zone.id === 'hand';
          const cardsToShow = (isDeck || isGrave) ? zone.cards.slice(0, 1) : zone.cards;

          return (
            <div
              key={zone.id}
              className="flex-none min-w-[80px] rounded-lg border border-red-900/20 bg-red-950/10 overflow-hidden"
            >
              {/* Zone header */}
              <div className="flex items-center gap-1 px-2 py-1 border-b border-red-900/10 bg-red-950/5">
                <span className="text-[9px] font-semibold text-red-400/60 truncate">{zone.name}</span>
                <span className="text-[8px] text-red-400/40 ml-auto font-mono">{zone.cards.length}</span>
              </div>

              {/* Cards */}
              <div className="p-1 flex flex-wrap gap-1 items-start">
                {cardsToShow.length === 0 && (
                  <div className="text-[8px] text-muted-foreground/20 italic p-1">-</div>
                )}
                {cardsToShow.map((card, i) => {
                  // Opponent's hand cards are always face-down for secrecy
                  const showFaceDown = isHand || card.faceDown;

                  return (
                    <div
                      key={card.id || i}
                      className={`
                        w-[40px] h-[56px] rounded-md overflow-hidden flex-none relative
                        border border-red-900/30
                        ${card.rot === 90 ? 'rotate-90' : card.rot === 180 ? 'rotate-180' : ''}
                      `}
                      style={{
                        backgroundImage: showFaceDown
                          ? `url(${CARD_BACK_URL})`
                          : `url(${card.img})`,
                        backgroundSize: 'cover',
                        backgroundPosition: 'center',
                      }}
                    >
                      {/* Count badge for deck/grave */}
                      {(isDeck || isGrave) && (
                        <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-[8px] text-white text-center py-0.5">
                          {zone.cards.length}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
