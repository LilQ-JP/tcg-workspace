/**
 * usePeer - React hook for P2P connection state
 */

import { useCallback, useEffect, useState } from 'react';
import { peerManager, ConnectionStatus, PeerMessage } from '@/lib/peerManager';

export function usePeer() {
  const [status, setStatus] = useState<ConnectionStatus>(peerManager.status);
  const [messages, setMessages] = useState<PeerMessage[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const unsubStatus = peerManager.onStatus((s) => {
      setStatus(s);
      if (s !== 'error') setError(null);
    });
    const unsubMsg = peerManager.onMessage((msg) => {
      setMessages(prev => [...prev.slice(-100), msg]);
    });
    const unsubErr = peerManager.onError((err) => {
      setError(err);
    });

    return () => {
      unsubStatus();
      unsubMsg();
      unsubErr();
    };
  }, []);

  const createRoom = useCallback(async () => {
    setError(null);
    return peerManager.createRoom();
  }, []);

  const joinRoom = useCallback(async (roomId: string) => {
    setError(null);
    return peerManager.joinRoom(roomId);
  }, []);

  const disconnect = useCallback(() => {
    peerManager.disconnect();
  }, []);

  const sendChat = useCallback((msg: string) => {
    peerManager.sendChat(msg);
  }, []);

  const syncState = useCallback((data: string) => {
    peerManager.syncState(data);
  }, []);

  const sendAction = useCallback((action: string, data?: unknown) => {
    peerManager.sendAction(action, data);
  }, []);

  return {
    status,
    messages,
    error,
    isConnected: status === 'connected',
    isHost: peerManager.isHost,
    myId: peerManager.myId,
    createRoom,
    joinRoom,
    disconnect,
    sendChat,
    syncState,
    sendAction,
  };
}
