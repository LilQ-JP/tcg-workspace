/**
 * useGameStore - React hook for subscribing to game state changes
 */

import { useCallback, useEffect, useState } from 'react';
import { gameStore } from '@/lib/gameStore';

export function useGameStore() {
  const [, forceUpdate] = useState(0);

  useEffect(() => {
    const unsub = gameStore.subscribe(() => forceUpdate(n => n + 1));
    return () => { unsub(); };
  }, []);

  return gameStore.getState();
}

export function useGameActions() {
  return {
    saveState: useCallback(() => gameStore.saveState(), []),
    undo: useCallback(() => gameStore.undo(), []),
    setPool: useCallback((images: string[]) => gameStore.setPool(images), []),
    initGame: useCallback(() => gameStore.initGame(), []),
    toggleSelection: useCallback((id: number) => gameStore.toggleSelection(id), []),
    clearSelection: useCallback(() => gameStore.clearSelection(), []),
    toggleHandMask: useCallback(() => gameStore.toggleHandMask(), []),
    addZone: useCallback((name: string) => gameStore.addZone(name), []),
    removeZone: useCallback((id: string) => gameStore.removeZone(id), []),
    renameZone: useCallback((id: string, name: string) => gameStore.renameZone(id, name), []),
    reorderZones: useCallback((from: string, to: string) => gameStore.reorderZones(from, to), []),
    moveCardToZone: useCallback((cardId: number, zoneId: string, flatten?: boolean) => gameStore.moveCardToZone(cardId, zoneId, flatten), []),
    moveSelectedCards: useCallback((zoneId: string, flatten?: boolean) => gameStore.moveSelectedCards(zoneId, flatten), []),
    moveToDeckEdge: useCallback((cardId: number, deckZoneId: string, pos: 'top' | 'bottom', fd: boolean) => gameStore.moveToDeckEdge(cardId, deckZoneId, pos, fd), []),
    shuffleDeck: useCallback((id?: string) => gameStore.shuffleDeck(id), []),
    drawCards: useCallback((count: number) => gameStore.drawCards(count), []),
    lookAtTopCards: useCallback((zoneId: string, count: number) => gameStore.lookAtTopCards(zoneId, count), []),
    applyDropStack: useCallback((draggedId: number, targetId: number, pos: 'under' | 'top', fd: boolean, flatten?: boolean) => gameStore.applyDropStack(draggedId, targetId, pos, fd, flatten), []),
    setCardRotation: useCallback((id: number, rot: 0 | 90 | 180) => gameStore.setCardRotation(id, rot), []),
    toggleCardFace: useCallback((id: number) => gameStore.toggleCardFace(id), []),
    setMultipleRotation: useCallback((ids: number[], rot: 0 | 90 | 180) => gameStore.setMultipleRotation(ids, rot), []),
    toggleMultipleFaces: useCallback((ids: number[]) => gameStore.toggleMultipleFaces(ids), []),
    discardRandomHand: useCallback(() => gameStore.discardRandomHand(), []),
    selectRandomHandCard: useCallback(() => gameStore.selectRandomHandCard(), []),
    removeTopCardToZone: useCallback((cardId: number, zoneId: string) => gameStore.removeTopCardToZone(cardId, zoneId), []),
    reset: useCallback(() => gameStore.reset(), []),
    serializeForSync: useCallback(() => gameStore.serializeForSync(), []),
  };
}
