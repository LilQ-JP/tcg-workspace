/**
 * Game Store - Core state management for the TCG Simulator
 * Design: Obsidian Table - Neo Material Dark Theme
 * All game state is managed here as a singleton store with event-based reactivity.
 */

export interface Card {
  id: number;
  img: string;
  faceDown: boolean;
  rot: 0 | 90 | 180;
  stack: Card[];     // cards underneath
  topCards: Card[];   // cards on top
}

export interface Zone {
  id: string;
  name: string;
  type: 'deck' | 'normal' | 'grave';
  isFixed: boolean;
  cards: Card[];
  width?: string;
  height?: string;
}

interface GameState {
  zones: Zone[];
  pool: string[];
  selectedCardIds: number[];
  modalWaitCards: Card[];
  stateHistory: { zones: Zone[]; modalWaitCards: Card[] }[];
  isHandMasked: boolean;
  cardIdCounter: number;
}

type Listener = () => void;

class GameStore {
  private state: GameState;
  private listeners: Set<Listener> = new Set();

  constructor() {
    this.state = {
      zones: [
        { id: 'deck', name: '山札', type: 'deck', isFixed: true, cards: [] },
        { id: 'hand', name: '手札', type: 'normal', isFixed: true, cards: [] },
        { id: 'grave', name: '捨て札', type: 'grave', isFixed: true, cards: [] },
        { id: 'play', name: 'プレイエリア', type: 'normal', isFixed: true, cards: [] },
        { id: 'wait', name: '待機エリア', type: 'normal', isFixed: true, cards: [] },
      ],
      pool: [],
      selectedCardIds: [],
      modalWaitCards: [],
      stateHistory: [],
      isHandMasked: false,
      cardIdCounter: 1,
    };
  }

  subscribe(listener: Listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach(fn => fn());
  }

  getState() {
    return this.state;
  }

  // --- State History ---
  saveState() {
    this.state.stateHistory.push({
      zones: JSON.parse(JSON.stringify(this.state.zones)),
      modalWaitCards: JSON.parse(JSON.stringify(this.state.modalWaitCards)),
    });
    if (this.state.stateHistory.length > 30) this.state.stateHistory.shift();
  }

  undo() {
    if (this.state.stateHistory.length > 0) {
      const prev = this.state.stateHistory.pop()!;
      this.state.zones = prev.zones;
      this.state.modalWaitCards = prev.modalWaitCards;
      this.state.selectedCardIds = [];
      this.notify();
    }
  }

  // --- Card Creation ---
  createCard(imgData: string): Card {
    return {
      id: this.state.cardIdCounter++,
      img: imgData,
      faceDown: true,
      rot: 0,
      stack: [],
      topCards: [],
    };
  }

  // --- Pool Management ---
  setPool(images: string[]) {
    this.state.pool = images;
    this.notify();
  }

  getPool() {
    return this.state.pool;
  }

  // --- Card Location ---
  findCardLocation(cardId: number): { zone: Zone; index: number; card: Card } | null {
    for (const z of this.state.zones) {
      for (let i = 0; i < z.cards.length; i++) {
        if (z.cards[i].id === cardId) return { zone: z, index: i, card: z.cards[i] };
      }
    }
    return null;
  }

  // --- Selection ---
  toggleSelection(cardId: number) {
    const idx = this.state.selectedCardIds.indexOf(cardId);
    if (idx === -1) {
      this.state.selectedCardIds.push(cardId);
    } else {
      this.state.selectedCardIds.splice(idx, 1);
    }
    this.notify();
  }

  clearSelection() {
    if (this.state.selectedCardIds.length > 0) {
      this.state.selectedCardIds = [];
      this.notify();
    }
  }

  getSelectedIds() {
    return this.state.selectedCardIds;
  }

  // --- Hand Mask ---
  toggleHandMask() {
    this.state.isHandMasked = !this.state.isHandMasked;
    this.notify();
  }

  // --- Zone Management ---
  addZone(name: string) {
    this.saveState();
    this.state.zones.push({
      id: 'z_' + Date.now(),
      name,
      type: 'normal',
      isFixed: false,
      cards: [],
    });
    this.notify();
  }

  removeZone(zoneId: string) {
    this.saveState();
    this.state.zones = this.state.zones.filter(z => z.id !== zoneId);
    this.notify();
  }

  renameZone(zoneId: string, newName: string) {
    this.saveState();
    const zone = this.state.zones.find(z => z.id === zoneId);
    if (zone) {
      zone.name = newName;
      this.notify();
    }
  }

  reorderZones(fromId: string, toId: string) {
    this.saveState();
    const fromIdx = this.state.zones.findIndex(z => z.id === fromId);
    const toIdx = this.state.zones.findIndex(z => z.id === toId);
    if (fromIdx !== -1 && toIdx !== -1) {
      const moved = this.state.zones.splice(fromIdx, 1)[0];
      this.state.zones.splice(toIdx, 0, moved);
      this.notify();
    }
  }

  // --- Card Movement ---
  moveCardToZone(cardId: number, targetZoneId: string, flatten: boolean = false) {
    const targetZone = this.state.zones.find(z => z.id === targetZoneId);
    if (!targetZone) return;
    const loc = this.findCardLocation(cardId);
    if (!loc) return;

    if (loc.zone.id === targetZoneId) {
      if (targetZone.type === 'deck' || targetZone.type === 'grave') {
        this.saveState();
        const card = loc.zone.cards.splice(loc.index, 1)[0];
        targetZone.cards.unshift(card);
        this.notify();
      }
      return;
    }

    this.saveState();
    const card = loc.zone.cards.splice(loc.index, 1)[0];

    let cardsToMove: Card[] = [];
    if (flatten) {
      if (card.topCards) cardsToMove.push(...card.topCards);
      cardsToMove.push(card);
      if (card.stack) cardsToMove.push(...card.stack);
      card.topCards = [];
      card.stack = [];
    } else {
      cardsToMove.push(card);
    }

    cardsToMove.forEach(c => {
      if (targetZone.type === 'deck') { c.faceDown = true; c.rot = 0; targetZone.cards.unshift(c); }
      else if (targetZone.type === 'grave') { c.faceDown = false; c.rot = 0; targetZone.cards.unshift(c); }
      else if (targetZone.id === 'hand') { c.faceDown = false; c.rot = 0; targetZone.cards.push(c); }
      else { targetZone.cards.push(c); }
    });
    this.notify();
  }

  moveSelectedCards(targetZoneId: string, flatten: boolean = false) {
    const targetZone = this.state.zones.find(z => z.id === targetZoneId);
    if (!targetZone || this.state.selectedCardIds.length === 0) return;

    const validIds = this.state.selectedCardIds.filter(id => {
      const loc = this.findCardLocation(id);
      return loc && loc.zone.id !== targetZoneId;
    });
    if (validIds.length === 0) return;

    this.saveState();
    const idsToProcess = (targetZone.type === 'deck' || targetZone.type === 'grave') ? [...validIds].reverse() : validIds;
    let cardsToMove: Card[] = [];

    idsToProcess.forEach(id => {
      const loc = this.findCardLocation(id);
      if (loc) {
        const card = loc.zone.cards.splice(loc.index, 1)[0];
        if (flatten) {
          if (card.topCards) cardsToMove.push(...card.topCards);
          cardsToMove.push(card);
          if (card.stack) cardsToMove.push(...card.stack);
          card.topCards = [];
          card.stack = [];
        } else {
          cardsToMove.push(card);
        }
      }
    });

    cardsToMove.forEach(c => {
      if (targetZone.type === 'deck') { c.faceDown = true; c.rot = 0; targetZone.cards.unshift(c); }
      else if (targetZone.type === 'grave') { c.faceDown = false; c.rot = 0; targetZone.cards.unshift(c); }
      else if (targetZone.id === 'hand') { c.faceDown = false; c.rot = 0; targetZone.cards.push(c); }
      else { targetZone.cards.push(c); }
    });

    this.state.selectedCardIds = [];
    this.notify();
  }

  // --- Deck Operations ---
  moveToDeckEdge(cardId: number, deckZoneId: string, position: 'top' | 'bottom', faceDown: boolean) {
    const loc = this.findCardLocation(cardId);
    const deckZone = this.state.zones.find(z => z.id === deckZoneId);
    if (!loc || !deckZone) return;
    this.saveState();
    const card = loc.zone.cards.splice(loc.index, 1)[0];
    card.faceDown = faceDown;
    card.rot = 0;
    if (position === 'top') deckZone.cards.unshift(card);
    else deckZone.cards.push(card);
    this.notify();
  }

  shuffleDeck(deckZoneId: string = 'deck') {
    const deck = this.state.zones.find(z => z.id === deckZoneId);
    if (deck) {
      this.saveState();
      deck.cards.sort(() => Math.random() - 0.5);
      this.notify();
    }
  }

  drawCards(count: number) {
    const deck = this.state.zones.find(z => z.type === 'deck');
    const hand = this.state.zones.find(z => z.id === 'hand');
    if (!deck || !hand) return false;
    if (deck.cards.length < count) return false;

    this.saveState();
    for (let i = 0; i < count; i++) {
      const c = deck.cards.shift()!;
      c.faceDown = false;
      c.rot = 0;
      hand.cards.push(c);
    }
    this.notify();
    return true;
  }

  lookAtTopCards(zoneId: string, count: number): Card[] | null {
    const zone = this.state.zones.find(z => z.id === zoneId);
    if (!zone || zone.cards.length < count) return null;

    this.saveState();
    const cards: Card[] = [];
    for (let i = 0; i < count; i++) {
      cards.push(zone.cards.shift()!);
    }
    this.state.modalWaitCards = cards;
    this.notify();
    return cards;
  }

  // --- Stacking ---
  applyDropStack(draggedId: number, targetId: number, position: 'under' | 'top', isFaceDown: boolean, flatten: boolean = false) {
    const draggedLoc = this.findCardLocation(draggedId);
    const targetLoc = this.findCardLocation(targetId);
    if (!draggedLoc || !targetLoc) return;

    this.saveState();
    const card = draggedLoc.zone.cards.splice(draggedLoc.index, 1)[0];

    let cardsToMove: Card[] = [];
    if (flatten) {
      if (card.topCards) cardsToMove.push(...card.topCards);
      cardsToMove.push(card);
      if (card.stack) cardsToMove.push(...card.stack);
      card.topCards = [];
      card.stack = [];
    } else {
      cardsToMove.push(card);
    }

    cardsToMove.forEach(c => {
      c.faceDown = isFaceDown;
      c.rot = 0;
      if (position === 'under') {
        if (!targetLoc.card.stack) targetLoc.card.stack = [];
        targetLoc.card.stack.push(c);
      } else {
        if (!targetLoc.card.topCards) targetLoc.card.topCards = [];
        targetLoc.card.topCards.push(c);
      }
    });
    this.notify();
  }

  // --- Card Properties ---
  setCardRotation(cardId: number, rot: 0 | 90 | 180) {
    const loc = this.findCardLocation(cardId);
    if (loc) {
      this.saveState();
      loc.card.rot = rot;
      this.notify();
    }
  }

  toggleCardFace(cardId: number) {
    const loc = this.findCardLocation(cardId);
    if (loc) {
      this.saveState();
      loc.card.faceDown = !loc.card.faceDown;
      this.notify();
    }
  }

  setMultipleRotation(cardIds: number[], rot: 0 | 90 | 180) {
    this.saveState();
    cardIds.forEach(id => {
      const loc = this.findCardLocation(id);
      if (loc) loc.card.rot = rot;
    });
    this.notify();
  }

  toggleMultipleFaces(cardIds: number[]) {
    this.saveState();
    cardIds.forEach(id => {
      const loc = this.findCardLocation(id);
      if (loc) loc.card.faceDown = !loc.card.faceDown;
    });
    this.notify();
  }

  // --- Random ---
  discardRandomHand() {
    const hand = this.state.zones.find(z => z.id === 'hand');
    const wait = this.state.zones.find(z => z.id === 'wait');
    if (!hand || !wait || hand.cards.length === 0) return null;

    this.saveState();
    const randomIdx = Math.floor(Math.random() * hand.cards.length);
    const card = hand.cards.splice(randomIdx, 1)[0];
    card.faceDown = false;
    card.rot = 0;
    wait.cards.push(card);
    this.notify();
    return card;
  }

  selectRandomHandCard() {
    const hand = this.state.zones.find(z => z.id === 'hand');
    if (!hand || hand.cards.length === 0) return;
    const randomIdx = Math.floor(Math.random() * hand.cards.length);
    this.state.selectedCardIds = [hand.cards[randomIdx].id];
    this.notify();
  }

  // --- Remove top card from stack ---
  removeTopCardToZone(cardId: number, targetZoneId: string) {
    const loc = this.findCardLocation(cardId);
    const targetZone = this.state.zones.find(z => z.id === targetZoneId);
    if (!loc || !targetZone) return;
    if (!loc.card.topCards || loc.card.topCards.length === 0) return;

    this.saveState();
    const s = loc.card.topCards.pop()!;
    s.faceDown = false;
    targetZone.cards.unshift(s);
    this.notify();
  }

  // --- Game Init ---
  initGame() {
    if (this.state.pool.length === 0) return false;
    this.saveState();
    const deckZone = this.state.zones.find(z => z.type === 'deck');
    if (!deckZone) return false;
    this.state.zones.forEach(z => z.cards = []);
    const deck = this.state.pool.map(img => this.createCard(img));
    deck.sort(() => Math.random() - 0.5);
    deckZone.cards = deck;
    this.state.selectedCardIds = [];
    this.state.modalWaitCards = [];
    this.notify();
    return true;
  }

  // --- Modal Wait Cards ---
  getModalWaitCards() {
    return this.state.modalWaitCards;
  }

  setModalWaitCards(cards: Card[]) {
    this.state.modalWaitCards = cards;
    this.notify();
  }

  returnModalWaitCards(targetZoneId?: string) {
    if (this.state.modalWaitCards.length === 0) return;
    const targetZone = targetZoneId
      ? this.state.zones.find(z => z.id === targetZoneId)
      : this.state.zones.find(z => z.id === 'wait') || this.state.zones[0];
    if (targetZone) {
      targetZone.cards.unshift(...this.state.modalWaitCards);
    }
    this.state.modalWaitCards = [];
    this.notify();
  }

  // --- Check if cards have stacks ---
  hasStacks(cardIds: number[]): boolean {
    return cardIds.some(id => {
      const loc = this.findCardLocation(id);
      return loc && ((loc.card.stack && loc.card.stack.length > 0) || (loc.card.topCards && loc.card.topCards.length > 0));
    });
  }

  // --- Serialize state for P2P sync ---
  serializeForSync(): string {
    return JSON.stringify({
      zones: this.state.zones,
      modalWaitCards: this.state.modalWaitCards,
      isHandMasked: this.state.isHandMasked,
    });
  }

  // --- Apply state from P2P peer (opponent's view) ---
  applyOpponentState(data: string) {
    try {
      const parsed = JSON.parse(data);
      // We store opponent state separately - this is handled by the P2P module
      return parsed;
    } catch {
      return null;
    }
  }

  // --- Full reset ---
  reset() {
    this.state.zones.forEach(z => z.cards = []);
    this.state.pool = [];
    this.state.selectedCardIds = [];
    this.state.modalWaitCards = [];
    this.state.stateHistory = [];
    this.state.isHandMasked = false;
    this.state.cardIdCounter = 1;
    this.notify();
  }
}

export const gameStore = new GameStore();

// Expose for debugging
if (typeof window !== 'undefined') {
  (window as any).__gameStore = gameStore;
}
