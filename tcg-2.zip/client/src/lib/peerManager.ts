/**
 * PeerManager - P2P connection management using PeerJS
 * Design: Obsidian Table - handles WebRTC peer-to-peer communication
 * for real-time TCG battle synchronization.
 */

import Peer, { DataConnection } from 'peerjs';

export type ConnectionStatus = 'disconnected' | 'connecting' | 'waiting' | 'connected' | 'error';

export interface PeerMessage {
  type: 'state-sync' | 'action' | 'chat' | 'ping' | 'pong' | 'ready' | 'game-start';
  payload: any;
  timestamp: number;
}

type StatusListener = (status: ConnectionStatus) => void;
type MessageListener = (msg: PeerMessage) => void;
type ErrorListener = (error: string) => void;

class PeerManager {
  private peer: Peer | null = null;
  private connection: DataConnection | null = null;
  private _status: ConnectionStatus = 'disconnected';
  private _myId: string = '';
  private _opponentId: string = '';
  private _isHost: boolean = false;

  private statusListeners: Set<StatusListener> = new Set();
  private messageListeners: Set<MessageListener> = new Set();
  private errorListeners: Set<ErrorListener> = new Set();

  get status() { return this._status; }
  get myId() { return this._myId; }
  get opponentId() { return this._opponentId; }
  get isHost() { return this._isHost; }
  get isConnected() { return this._status === 'connected'; }

  private setStatus(status: ConnectionStatus) {
    this._status = status;
    this.statusListeners.forEach(fn => fn(status));
  }

  onStatus(listener: StatusListener) {
    this.statusListeners.add(listener);
    return () => this.statusListeners.delete(listener);
  }

  onMessage(listener: MessageListener) {
    this.messageListeners.add(listener);
    return () => this.messageListeners.delete(listener);
  }

  onError(listener: ErrorListener) {
    this.errorListeners.add(listener);
    return () => this.errorListeners.delete(listener);
  }

  private generateRoomId(): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }

  /**
   * Create a room (host mode)
   * Returns the room ID that the opponent should use to connect
   */
  async createRoom(): Promise<string> {
    return new Promise((resolve, reject) => {
      const roomId = this.generateRoomId();
      const peerId = `tcg-battle-${roomId}`;

      this.cleanup();
      this._isHost = true;
      this.setStatus('connecting');

      this.peer = new Peer(peerId, {
        debug: 0,
      });

      this.peer.on('open', (id) => {
        this._myId = id;
        this.setStatus('waiting');
        resolve(roomId);
      });

      this.peer.on('connection', (conn) => {
        this.connection = conn;
        this._opponentId = conn.peer;
        this.setupConnection(conn);
      });

      this.peer.on('error', (err) => {
        console.error('PeerJS error:', err);
        this.errorListeners.forEach(fn => fn(err.message || 'Connection error'));
        if (this._status !== 'connected') {
          this.setStatus('error');
          reject(err);
        }
      });

      this.peer.on('disconnected', () => {
        if (this._status === 'connected') {
          this.setStatus('disconnected');
        }
      });
    });
  }

  /**
   * Join a room (guest mode)
   */
  async joinRoom(roomId: string): Promise<void> {
    return new Promise((resolve, reject) => {
      const targetPeerId = `tcg-battle-${roomId.toUpperCase()}`;

      this.cleanup();
      this._isHost = false;
      this.setStatus('connecting');

      this.peer = new Peer({
        debug: 0,
      });

      this.peer.on('open', (id) => {
        this._myId = id;
        const conn = this.peer!.connect(targetPeerId, {
          reliable: true,
        });

        this.connection = conn;
        this._opponentId = targetPeerId;
        this.setupConnection(conn);

        conn.on('open', () => {
          resolve();
        });

        conn.on('error', (err) => {
          this.errorListeners.forEach(fn => fn('Failed to connect to room'));
          this.setStatus('error');
          reject(err);
        });
      });

      this.peer.on('error', (err) => {
        console.error('PeerJS error:', err);
        this.errorListeners.forEach(fn => fn(err.message || 'Connection error'));
        this.setStatus('error');
        reject(err);
      });

      // Timeout after 15 seconds
      setTimeout(() => {
        if (this._status !== 'connected') {
          this.errorListeners.forEach(fn => fn('Connection timed out'));
          this.setStatus('error');
          reject(new Error('Connection timed out'));
        }
      }, 15000);
    });
  }

  private setupConnection(conn: DataConnection) {
    conn.on('open', () => {
      this.setStatus('connected');
      // Start ping/pong for keepalive
      this.startPingPong();
    });

    conn.on('data', (data) => {
      try {
        const msg = data as PeerMessage;
        if (msg.type === 'ping') {
          this.send({ type: 'pong', payload: null, timestamp: Date.now() });
          return;
        }
        if (msg.type === 'pong') return;
        this.messageListeners.forEach(fn => fn(msg));
      } catch (e) {
        console.error('Failed to parse message:', e);
      }
    });

    conn.on('close', () => {
      this.setStatus('disconnected');
      this._opponentId = '';
    });

    conn.on('error', (err) => {
      console.error('Connection error:', err);
      this.errorListeners.forEach(fn => fn('Connection lost'));
    });
  }

  private pingInterval: ReturnType<typeof setInterval> | null = null;

  private startPingPong() {
    if (this.pingInterval) clearInterval(this.pingInterval);
    this.pingInterval = setInterval(() => {
      if (this.isConnected) {
        this.send({ type: 'ping', payload: null, timestamp: Date.now() });
      }
    }, 10000);
  }

  /**
   * Send a message to the connected peer
   */
  send(msg: PeerMessage) {
    if (this.connection && this.connection.open) {
      this.connection.send(msg);
    }
  }

  /**
   * Send game state sync
   */
  syncState(stateData: string) {
    this.send({
      type: 'state-sync',
      payload: stateData,
      timestamp: Date.now(),
    });
  }

  /**
   * Send a game action
   */
  sendAction(action: string, data?: any) {
    this.send({
      type: 'action',
      payload: { action, data },
      timestamp: Date.now(),
    });
  }

  /**
   * Send a chat message
   */
  sendChat(message: string) {
    this.send({
      type: 'chat',
      payload: message,
      timestamp: Date.now(),
    });
  }

  /**
   * Disconnect and cleanup
   */
  disconnect() {
    this.cleanup();
    this.setStatus('disconnected');
  }

  private cleanup() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
    if (this.connection) {
      this.connection.close();
      this.connection = null;
    }
    if (this.peer) {
      this.peer.destroy();
      this.peer = null;
    }
    this._myId = '';
    this._opponentId = '';
  }
}

export const peerManager = new PeerManager();
