/**
 * Home Page - TCG Battle Simulator
 * Design: Obsidian Table - Neo Material Dark Theme
 * macOS-like floating toolbar, glass panels, dark card table aesthetic
 * P2P sync: auto-sends game state to opponent on every state change
 */

import { useState, useEffect, useRef } from 'react';
import { GameBoard } from '@/components/GameBoard';
import { Toolbar } from '@/components/Toolbar';
import { ConnectionPanel } from '@/components/ConnectionPanel';
import { OpponentBoard } from '@/components/OpponentBoard';
import { ChatPanel } from '@/components/ChatPanel';
import { usePeer } from '@/hooks/usePeer';
import { gameStore } from '@/lib/gameStore';

export default function Home() {
  const [showConnection, setShowConnection] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const peer = usePeer();
  const syncTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Auto-sync game state to opponent whenever local state changes
  useEffect(() => {
    if (!peer.isConnected) return;

    const unsub = gameStore.subscribe(() => {
      // Debounce sync to avoid flooding
      if (syncTimerRef.current) clearTimeout(syncTimerRef.current);
      syncTimerRef.current = setTimeout(() => {
        const data = gameStore.serializeForSync();
        peer.syncState(data);
      }, 100);
    });

    // Send initial state
    const data = gameStore.serializeForSync();
    peer.syncState(data);

    return () => {
      unsub();
      if (syncTimerRef.current) clearTimeout(syncTimerRef.current);
    };
  }, [peer.isConnected, peer.syncState]);

  return (
    <div className="h-screen w-screen overflow-hidden bg-background flex flex-col relative">
      {/* Opponent Board - shown when connected */}
      {peer.isConnected && (
        <div className="flex-none h-[28vh] border-b border-border/50 relative overflow-hidden">
          <OpponentBoard messages={peer.messages} />
          <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
        </div>
      )}

      {/* Main Game Board */}
      <div className="flex-1 relative overflow-hidden">
        <GameBoard />
      </div>

      {/* Floating Toolbar - macOS Dock style */}
      <Toolbar
        isConnected={peer.isConnected}
        onToggleConnection={() => setShowConnection(!showConnection)}
        onToggleChat={() => setShowChat(!showChat)}
      />

      {/* Connection Panel - Slide-in from right */}
      {showConnection && (
        <ConnectionPanel
          peer={peer}
          onClose={() => setShowConnection(false)}
        />
      )}

      {/* Chat Panel - Slide-in from right */}
      {showChat && peer.isConnected && (
        <ChatPanel
          peer={peer}
          onClose={() => setShowChat(false)}
        />
      )}
    </div>
  );
}
