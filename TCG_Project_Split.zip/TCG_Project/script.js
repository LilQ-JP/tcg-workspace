let cardIdCounter = 1;
        let pool = [];
        let selectedCardIds = [];
        let modalWaitCards = [];
        let stateHistory = [];

        // 手札マスク用フラグ
        let isHandMasked = false;

        let zones = [
            { id: 'deck', name: '山札', type: 'deck', isFixed: true, cards: [] },
            { id: 'hand', name: '手札', type: 'normal', isFixed: true, cards: [] },
            { id: 'grave', name: '捨て札', type: 'grave', isFixed: true, cards: [] },
            { id: 'play', name: 'プレイエリア', type: 'normal', isFixed: true, cards: [] },
            { id: 'wait', name: '待機エリア', type: 'normal', isFixed: true, cards: [] }
        ];

        const field = document.getElementById('field');
        const menu = document.getElementById('context-menu');
        const modalOverlay = document.getElementById('modal-overlay');
        const modalContent = document.getElementById('modal-content');
        const modalWaitContent = document.getElementById('modal-wait-content');
        const modalWaitWrapper = document.getElementById('modal-wait-wrapper');
        const modalTitle = document.getElementById('modal-title');
        const modalButtons = document.getElementById('modal-buttons');

        function toggleHandMask() {
            isHandMasked = !isHandMasked;
            render();
        }

        function askAB(message, textA, textB) {
            return new Promise(resolve => {
                const overlay = document.getElementById('dialog-overlay');
                document.getElementById('dialog-msg').innerHTML = message.replace(/\n/g, '<br>');

                const btnA = document.getElementById('dialog-btn-a');
                const btnB = document.getElementById('dialog-btn-b');
                btnA.textContent = `A. ${textA}`;
                btnB.textContent = `B. ${textB}`;

                btnA.replaceWith(btnA.cloneNode(true));
                btnB.replaceWith(btnB.cloneNode(true));
                const newBtnA = document.getElementById('dialog-btn-a');
                const newBtnB = document.getElementById('dialog-btn-b');

                newBtnA.onclick = () => { overlay.style.display = 'none'; resolve('A'); };
                newBtnB.onclick = () => { overlay.style.display = 'none'; resolve('B'); };

                overlay.style.display = 'flex';
            });
        }

        function saveState() {
            stateHistory.push({
                zones: JSON.parse(JSON.stringify(zones)),
                modalWaitCards: JSON.parse(JSON.stringify(modalWaitCards))
            });
            if (stateHistory.length > 20) stateHistory.shift();
        }

        function undo() {
            if (stateHistory.length > 0) {
                const prevState = stateHistory.pop();
                zones = prevState.zones;
                modalWaitCards = prevState.modalWaitCards;
                selectedCardIds = [];
                closeModal();
                render();
            }
        }

        function openPreview(imgSrc) {
            const overlay = document.getElementById('preview-overlay');
            const popup = document.getElementById('preview-popup');
            document.getElementById('preview-img').src = imgSrc;
            overlay.style.display = 'block';
            // 初期位置：画面中央
            const pw = Math.min(window.innerWidth * 0.88, 700);
            popup.style.left = Math.max(10, (window.innerWidth - pw) / 2) + 'px';
            popup.style.top = Math.max(10, (window.innerHeight - pw * 1.1) / 2) + 'px';
            popup.style.width = pw + 'px';
            // ドラッグ可能にする
            makeDraggable(popup);
        }
        function closePreview() {
            document.getElementById('preview-overlay').style.display = 'none';
        }
        function makeDraggable(el) {
            el._dragHandler && el.removeEventListener('mousedown', el._dragHandler);
            let startX, startY, origLeft, origTop;
            const onMouseMove = (e) => {
                const nx = origLeft + (e.clientX - startX);
                const ny = origTop + (e.clientY - startY);
                el.style.left = Math.max(0, Math.min(window.innerWidth - el.offsetWidth, nx)) + 'px';
                el.style.top = Math.max(0, Math.min(window.innerHeight - el.offsetHeight, ny)) + 'px';
            };
            const onMouseUp = () => {
                document.removeEventListener('mousemove', onMouseMove);
                document.removeEventListener('mouseup', onMouseUp);
                el.style.cursor = 'grab';
            };
            el._dragHandler = (e) => {
                if (e.target.id === 'preview-close-btn' || e.target.tagName === 'IMG') return;
                startX = e.clientX; startY = e.clientY;
                origLeft = parseInt(el.style.left) || 0;
                origTop = parseInt(el.style.top) || 0;
                el.style.cursor = 'grabbing';
                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            };
            el.style.cursor = 'grab';
            el.addEventListener('mousedown', el._dragHandler);
        }

        function showMenuAt(e, menuElement) {
            menuElement.style.display = 'block';
            menuElement.style.position = 'fixed';
            // 既存の×ボタンを削除して再追加
            const existing = menuElement.querySelector('.menu-close-btn');
            if (existing) existing.remove();
            const closeBtn = document.createElement('button');
            closeBtn.className = 'menu-close-btn';
            closeBtn.textContent = '×';
            closeBtn.title = '閉じる';
            closeBtn.onclick = (ev) => { ev.stopPropagation(); menuElement.style.display = 'none'; };
            menuElement.insertBefore(closeBtn, menuElement.firstChild);

            let x = e.clientX;
            let y = e.clientY;
            const rect = menuElement.getBoundingClientRect();

            if (x + rect.width > window.innerWidth) x = window.innerWidth - rect.width - 10;
            if (y + rect.height > window.innerHeight) y = window.innerHeight - rect.height - 10;

            menuElement.style.left = `${x}px`;
            menuElement.style.top = `${y}px`;
        }

        function addZone() {
            const name = prompt("新しいエリアの名前を入力してください", "新エリア");
            if (name) {
                saveState();
                zones.push({ id: 'z_' + Date.now(), name: name, type: 'normal', isFixed: false, cards: [] });
                render();
            }
        }

        function createCard(imgData) {
            return { id: cardIdCounter++, img: imgData, faceDown: true, rot: 0, stack: [], topCards: [] };
        }

        function findCardLocation(cardId) {
            for (let z of zones) {
                for (let i = 0; i < z.cards.length; i++) {
                    if (z.cards[i].id === cardId) return { zone: z, index: i, card: z.cards[i] };
                }
            }
            return null;
        }

        async function processStackedCards(cards) {
            const hasStacks = cards.some(c => (c.stack && c.stack.length > 0) || (c.topCards && c.topCards.length > 0));
            if (!hasStacks) return cards;

            const choice = await askAB("重なっているカードが含まれています。\nどのように移動させますか？", "重なったまま移動する", "バラバラにして移動する");
            if (choice === 'A') return cards;

            let flattened = [];
            cards.forEach(c => {
                if (c.topCards) flattened.push(...c.topCards);
                flattened.push(c);
                if (c.stack) flattened.push(...c.stack);
                c.topCards = [];
                c.stack = [];
            });
            return flattened;
        }

        function render() {
            const fieldTop = document.getElementById('field-top');
            const fieldMiddle = document.getElementById('field-middle');
            const fieldBottom = document.getElementById('field-bottom');
            if (fieldTop) fieldTop.innerHTML = '';
            if (fieldMiddle) fieldMiddle.innerHTML = '';
            if (fieldBottom) fieldBottom.innerHTML = '';

            zones.forEach(z => {
                const zEl = document.createElement('div');
                zEl.className = 'zone';

                // 保存されたサイズを復元
                if (z.width) zEl.style.width = z.width;
                if (z.height) zEl.style.height = z.height;

                zEl.innerHTML = `<div class="zone-header">
                <span class="zone-title">${z.name}</span>
                <span class="zone-drag-handle" draggable="true" title="ドラッグしてエリアを移動">≡</span>
            </div>
            <div class="zone-cards"></div>`;
                const zoneCards = zEl.querySelector('.zone-cards');

                // リサイズ後のサイズをzoneデータに保存するObserver
                const ro = new ResizeObserver(() => {
                    const w = zEl.style.width;
                    const h = zEl.style.height;
                    if (w) z.width = w;
                    if (h) z.height = h;
                });
                ro.observe(zEl);

                const handle = zEl.querySelector('.zone-drag-handle');
                handle.ondragstart = e => {
                    e.dataTransfer.setData('zone', z.id);
                    e.stopPropagation();
                };

                zEl.ondragover = e => e.preventDefault();
                zEl.ondrop = async e => {
                    e.preventDefault();
                    const draggedZoneId = e.dataTransfer.getData('zone');
                    if (draggedZoneId && draggedZoneId !== z.id) {
                        saveState();
                        const fromIdx = zones.findIndex(zone => zone.id === draggedZoneId);
                        const toIdx = zones.findIndex(zone => zone.id === z.id);
                        const movedZone = zones.splice(fromIdx, 1)[0];
                        zones.splice(toIdx, 0, movedZone);
                        render();
                        return;
                    }

                    const draggedId = parseInt(e.dataTransfer.getData('text/plain'));
                    if (isNaN(draggedId)) return;

                    // 山札エリアへのドロップは重ね判定なし、上下置きのみ
                    if (z.type === 'deck') {
                        const loc = findCardLocation(draggedId);
                        if (loc && loc.zone.id === z.id) return; // 同じ山札内なら無視
                        showDeckDropMenu(e, draggedId, z);
                        return;
                    }

                    if (selectedCardIds.includes(draggedId) && selectedCardIds.length > 1) {
                        await moveSelectedCards(z.id);
                    } else {
                        await moveCardToZone(draggedId, z.id);
                    }
                };

                zEl.oncontextmenu = e => { e.preventDefault(); e.stopPropagation(); showZoneMenu(e, z); };

                const cardsToRender = (z.type === 'deck' || z.type === 'grave') ? z.cards.slice(0, 1) : z.cards;
                let faceDownIndex = 1;

                cardsToRender.forEach(c => {
                    const cEl = document.createElement('div');
                    const isSelected = selectedCardIds.includes(c.id);

                    let visualFaceDown = c.faceDown;
                    if (z.id === 'hand' && isHandMasked) {
                        visualFaceDown = true;
                    }

                    cEl.className = `card ${visualFaceDown ? 'face-down' : ''} ${isSelected ? 'selected' : ''} rotated-${c.rot}`;
                    if (!visualFaceDown) cEl.style.backgroundImage = `url(${c.img})`;
                    cEl.draggable = true;

                    if (isSelected) {
                        const badge = document.createElement('div');
                        badge.className = 'order-badge';
                        badge.textContent = selectedCardIds.indexOf(c.id) + 1;
                        cEl.appendChild(badge);
                    }

                    if (visualFaceDown && z.type !== 'deck') {
                        const fdBadge = document.createElement('div');
                        fdBadge.className = 'facedown-badge';
                        fdBadge.textContent = faceDownIndex++;
                        cEl.appendChild(fdBadge);
                    }

                    if (z.type === 'deck' || z.type === 'grave') {
                        const zoneCountBadge = document.createElement('div');
                        zoneCountBadge.className = 'zone-count-badge';
                        zoneCountBadge.textContent = `${z.cards.length}枚`;
                        cEl.appendChild(zoneCountBadge);
                    }

                    if (c.stack && c.stack.length > 0) {
                        const sBadge = document.createElement('div');
                        sBadge.className = 'badge-under';
                        sBadge.textContent = `下: ${c.stack.length}枚`;
                        cEl.appendChild(sBadge);
                    }

                    if (c.topCards && c.topCards.length > 0) {
                        const latestTopCard = c.topCards[c.topCards.length - 1];
                        const topLayer = document.createElement('div');
                        topLayer.className = 'top-layer';

                        if (latestTopCard.faceDown) {
                            topLayer.style.backgroundImage = "url('https://via.placeholder.com/70x100/333333/cccccc?text=BACK')";
                            topLayer.style.opacity = "1";
                            topLayer.classList.add('rotated-90');
                        } else {
                            topLayer.style.backgroundImage = `url(${latestTopCard.img})`;
                            topLayer.style.opacity = "1";
                            topLayer.classList.remove('rotated-90');
                        }
                        cEl.appendChild(topLayer);

                        const tBadge = document.createElement('div');
                        tBadge.className = 'badge-top';
                        tBadge.textContent = `上: ${c.topCards.length}枚`;
                        cEl.appendChild(tBadge);
                    }

                    cEl.ondragstart = e => { e.dataTransfer.setData('text/plain', c.id); };
                    cEl.ondragover = e => { e.preventDefault(); e.stopPropagation(); };
                    cEl.ondrop = async e => {
                        e.preventDefault(); e.stopPropagation();
                        const draggedId = parseInt(e.dataTransfer.getData('text/plain'));
                        if (isNaN(draggedId) || draggedId === c.id) return;

                        // 山札のカード上にドロップした場合は上下置きのみ（重ね処理なし）
                        if (z.type === 'deck') {
                            showDeckDropMenu(e, draggedId, z);
                            return;
                        }

                        if (selectedCardIds.includes(draggedId) && selectedCardIds.length > 1) {
                            showDropChoiceMenuForMulti(e, selectedCardIds, c.id);
                        } else {
                            showDropChoiceMenu(e, draggedId, c.id);
                        }
                    };

                    cEl.onclick = e => {
                        e.stopPropagation();
                        const idx = selectedCardIds.indexOf(c.id);
                        if (idx === -1) { selectedCardIds.push(c.id); }
                        else { selectedCardIds.splice(idx, 1); }
                        render();
                    };

                    // ダブルクリック画像拡大は削除（右クリックメニューに移動）

                    cEl.oncontextmenu = e => {
                        e.preventDefault(); e.stopPropagation();
                        if (z.type === 'deck' || z.type === 'grave') {
                            showZoneMenu(e, z);
                        } else {
                            showCardMenu(e, c, cEl);
                        }
                    };

                    zoneCards.appendChild(cEl);
                });

                if (z.id === 'hand') {
                    if (fieldBottom) fieldBottom.appendChild(zEl);
                } else if (z.id === 'play') {
                    if (fieldTop) fieldTop.appendChild(zEl);
                } else {
                    if (fieldMiddle) fieldMiddle.appendChild(zEl);
                }
            });
        }

        async function moveCardToZone(cardId, targetZoneId) {
            const targetZone = zones.find(z => z.id === targetZoneId);
            if (!targetZone) return;
            const loc = findCardLocation(cardId);
            if (!loc) return;

            if (loc.zone.id === targetZoneId) {
                if (targetZone.type === 'deck' || targetZone.type === 'grave') {
                    saveState();
                    const card = loc.zone.cards.splice(loc.index, 1)[0];
                    targetZone.cards.unshift(card);
                    render();
                }
                return;
            }

            let hasStacks = (loc.card.stack && loc.card.stack.length > 0) || (loc.card.topCards && loc.card.topCards.length > 0);
            let flatten = false;
            if (hasStacks) {
                const choice = await askAB("重なっているカードが含まれています。\nどのように移動させますか？", "重なったまま移動する", "バラバラにして移動する");
                flatten = (choice === 'B');
            }

            saveState();
            const card = loc.zone.cards.splice(loc.index, 1)[0];

            let cardsToMove = [];
            if (flatten) {
                if (card.topCards) cardsToMove.push(...card.topCards);
                cardsToMove.push(card);
                if (card.stack) cardsToMove.push(...card.stack);
                card.topCards = []; card.stack = [];
            } else {
                cardsToMove.push(card);
            }

            cardsToMove.forEach(c => {
                if (targetZone.type === 'deck') { c.faceDown = true; c.rot = 0; targetZone.cards.unshift(c); }
                else if (targetZone.type === 'grave') { c.faceDown = false; c.rot = 0; targetZone.cards.unshift(c); }
                else if (targetZone.id === 'hand') { c.faceDown = false; c.rot = 0; targetZone.cards.push(c); }
                else { targetZone.cards.push(c); }
            });
            render();
        }

        async function moveSelectedCards(targetZoneId) {
            const targetZone = zones.find(z => z.id === targetZoneId);
            if (!targetZone || selectedCardIds.length === 0) return;

            const validIds = selectedCardIds.filter(id => {
                const loc = findCardLocation(id);
                return loc && loc.zone.id !== targetZoneId;
            });
            if (validIds.length === 0) return;

            let hasStacks = false;
            validIds.forEach(id => {
                const loc = findCardLocation(id);
                if (loc && ((loc.card.stack && loc.card.stack.length > 0) || (loc.card.topCards && loc.card.topCards.length > 0))) hasStacks = true;
            });

            let flatten = false;
            if (hasStacks) {
                const choice = await askAB("重なっているカードが含まれています。\nどのように移動させますか？", "重なったまま一括移動", "すべてバラバラにして移動");
                flatten = (choice === 'B');
            }

            saveState();

            const idsToProcess = (targetZone.type === 'deck' || targetZone.type === 'grave') ? validIds.reverse() : validIds;
            let cardsToMove = [];

            idsToProcess.forEach(id => {
                const loc = findCardLocation(id);
                if (loc) {
                    const card = loc.zone.cards.splice(loc.index, 1)[0];
                    if (flatten) {
                        if (card.topCards) cardsToMove.push(...card.topCards);
                        cardsToMove.push(card);
                        if (card.stack) cardsToMove.push(...card.stack);
                        card.topCards = []; card.stack = [];
                    } else {
                        cardsToMove.push(card);
                    }
                }
            });

            cardsToMove.forEach(c => {
                if (targetZone.type === 'deck') { c.faceDown = true; c.rot = 0; targetZone.cards.unshift(c); }
                else if (targetZone.type === 'grave') { c.faceDown = false; c.rot = 0; targetZone.cards.unshift(c); }
                else if (targetZone.id === 'hand') { c.faceDown = false; c.rot = 0; targetZone.cards.push(c); }
                else { targetZone.cards.push(c); }
            });

            clearSelection();
            render();
        }

        function clearSelection() {
            if (selectedCardIds.length > 0) {
                selectedCardIds = [];
                render();
            }
        }

        // 山札にドラッグした時の特殊メニュー（重ね判定なし、上下のみ）
        function showDeckDropMenu(e, draggedId, deckZone) {
            menu.innerHTML = '';
            addMenuGroup('山札の上下に置く');
            addMenuItem('🔝 山札の一番上に置く (裏向き)', () => moveToDeckEdge(draggedId, deckZone, 'top', true));
            addMenuItem('🔝 山札の一番上に置く (表向き)', () => moveToDeckEdge(draggedId, deckZone, 'top', false));
            addMenuItem('🔜 山札の一番下に置く (裏向き)', () => moveToDeckEdge(draggedId, deckZone, 'bottom', true));
            addMenuItem('🔜 山札の一番下に置く (表向き)', () => moveToDeckEdge(draggedId, deckZone, 'bottom', false));
            showMenuAt(e, menu);
        }
        async function moveToDeckEdge(cardId, deckZone, position, faceDown) {
            const loc = findCardLocation(cardId);
            if (!loc) return;
            saveState();
            const card = loc.zone.cards.splice(loc.index, 1)[0];
            card.faceDown = faceDown; card.rot = 0;
            if (position === 'top') deckZone.cards.unshift(card);
            else deckZone.cards.push(card);
            render();
        }

        function showDropChoiceMenu(e, draggedId, targetId) {
            menu.innerHTML = '';
            addMenuGroup('重ねる処理の選択');
            addMenuItem('🔽 表向きで「下」に置く', () => applyDropStack(draggedId, targetId, 'under', false));
            addMenuItem('🔽 裏向きで「下」に置く', () => applyDropStack(draggedId, targetId, 'under', true));
            addMenuItem('🔼 表向きで「上」に置く', () => applyDropStack(draggedId, targetId, 'top', false));
            addMenuItem('🔼 裏向きで「上」に置く', () => applyDropStack(draggedId, targetId, 'top', true));
            showMenuAt(e, menu);
        }

        function showDropChoiceMenuForMulti(e, draggedIds, targetId) {
            menu.innerHTML = '';
            addMenuGroup(`選択中の${draggedIds.length}枚を重ねる`);
            addMenuItem('🔽 表向きで「下」に置く', () => applyDropStackMulti(draggedIds, targetId, 'under', false));
            addMenuItem('🔽 裏向きで「下」に置く', () => applyDropStackMulti(draggedIds, targetId, 'under', true));
            addMenuItem('🔼 表向きで「上」に置く', () => applyDropStackMulti(draggedIds, targetId, 'top', false));
            addMenuItem('🔼 裏向きで「上」に置く', () => applyDropStackMulti(draggedIds, targetId, 'top', true));
            showMenuAt(e, menu);
        }

        async function applyDropStack(draggedId, targetId, position, isFaceDown) {
            const draggedLoc = findCardLocation(draggedId);
            const targetLoc = findCardLocation(targetId);
            if (!draggedLoc || !targetLoc) return;

            let hasStacks = (draggedLoc.card.stack && draggedLoc.card.stack.length > 0) || (draggedLoc.card.topCards && draggedLoc.card.topCards.length > 0);
            let flatten = false;
            if (hasStacks) {
                const choice = await askAB("重なっているカードを重ねようとしています。\nどのように重ねますか？", "そのままの塊で重ねる", "バラバラに分解して重ねる");
                flatten = (choice === 'B');
            }

            saveState();
            const card = draggedLoc.zone.cards.splice(draggedLoc.index, 1)[0];

            let cardsToMove = [];
            if (flatten) {
                if (card.topCards) cardsToMove.push(...card.topCards);
                cardsToMove.push(card);
                if (card.stack) cardsToMove.push(...card.stack);
                card.topCards = []; card.stack = [];
            } else {
                cardsToMove.push(card);
            }

            cardsToMove.forEach(c => {
                c.faceDown = isFaceDown; c.rot = 0;
                if (position === 'under') {
                    if (!targetLoc.card.stack) targetLoc.card.stack = [];
                    targetLoc.card.stack.push(c);
                } else if (position === 'top') {
                    if (!targetLoc.card.topCards) targetLoc.card.topCards = [];
                    targetLoc.card.topCards.push(c);
                }
            });
            render();
        }

        async function applyDropStackMulti(draggedIds, targetId, position, isFaceDown) {
            const targetLoc = findCardLocation(targetId);
            if (!targetLoc) return;

            let rawCards = [];
            draggedIds.forEach(id => {
                const loc = findCardLocation(id);
                if (loc) rawCards.push(loc.card);
            });

            let hasStacks = false;
            rawCards.forEach(c => {
                if ((c.stack && c.stack.length > 0) || (c.topCards && c.topCards.length > 0)) hasStacks = true;
            });

            let flatten = false;
            if (hasStacks) {
                const choice = await askAB("重なっているカードが含まれています。\nどのように重ねますか？", "そのままの塊で重ねる", "すべてバラバラにして重ねる");
                flatten = (choice === 'B');
            }

            saveState();
            let cardsToMove = [];
            draggedIds.forEach(id => {
                const loc = findCardLocation(id);
                if (loc) {
                    const card = loc.zone.cards.splice(loc.index, 1)[0];
                    if (flatten) {
                        if (card.topCards) cardsToMove.push(...card.topCards);
                        cardsToMove.push(card);
                        if (card.stack) cardsToMove.push(...card.stack);
                        card.topCards = []; card.stack = [];
                    } else {
                        cardsToMove.push(card);
                    }
                }
            });

            cardsToMove.forEach(c => {
                c.faceDown = isFaceDown; c.rot = 0;
                if (position === 'under') {
                    if (!targetLoc.card.stack) targetLoc.card.stack = [];
                    targetLoc.card.stack.push(c);
                } else if (position === 'top') {
                    if (!targetLoc.card.topCards) targetLoc.card.topCards = [];
                    targetLoc.card.topCards.push(c);
                }
            });
            clearSelection();
            render();
        }

        function lookAtTopCards(zone) {
            const countInput = prompt("上から何枚見ますか？ (例: 3)", "3");
            const count = parseInt(countInput);
            if (!isNaN(count) && count > 0) {
                if (zone.cards.length < count) return alert('山札の枚数が足りません！');
                saveState();
                for (let i = 0; i < count; i++) {
                    modalWaitCards.push(zone.cards.shift());
                }
                currentModalMode = 'peek';
                currentViewerZone = zone;
                updateModalView();
                openModalCommon();
            }
        }

        function drawCards(zone) {
            const countInput = prompt("何枚引きますか？", "1");
            const count = parseInt(countInput);
            if (!isNaN(count) && count > 0) {
                if (zone.cards.length < count) return alert('山札の枚数が足りません！');
                saveState();
                const handZone = zones.find(z => z.id === 'hand');
                if (!handZone) return alert('手札エリアが見つかりません');

                for (let i = 0; i < count; i++) {
                    const c = zone.cards.shift();
                    c.faceDown = false;
                    c.rot = 0;
                    handZone.cards.push(c);
                }
                render();
            }
        }

        async function discardRandomHandToWait() {
            const handZone = zones.find(z => z.id === 'hand');
            const waitZone = zones.find(z => z.id === 'wait');
            if (!handZone || !waitZone) return;
            if (handZone.cards.length === 0) return alert("手札がありません！");

            saveState();
            const randomIdx = Math.floor(Math.random() * handZone.cards.length);
            const card = handZone.cards.splice(randomIdx, 1)[0];

            let cardsToMove = [card];
            if ((card.stack && card.stack.length > 0) || (card.topCards && card.topCards.length > 0)) {
                const choice = await askAB("ランダム選択されたカードに重なりがあります。\nどう移動させますか？", "重なったまま移動", "バラバラにする");
                if (choice === 'B') {
                    cardsToMove = [];
                    if (card.topCards) cardsToMove.push(...card.topCards);
                    cardsToMove.push(card);
                    if (card.stack) cardsToMove.push(...card.stack);
                    card.topCards = []; card.stack = [];
                }
            }

            cardsToMove.forEach(c => {
                c.faceDown = false;
                c.rot = 0;
                waitZone.cards.push(c);
            });
            render();
        }

        function showZoneMenu(e, zone) {
            menu.innerHTML = '';

            if (selectedCardIds.length > 0) {
                addMenuItem(`📥 選択中の ${selectedCardIds.length} 枚をここに移動`, () => moveSelectedCards(zone.id));
                addDivider();
            }

            if (zone.id === 'hand') {
                addMenuItem(isHandMasked ? '🎴 手札を見る (マスク解除)' : '🎴 手札を隠す (マスク)', () => toggleHandMask());
                addDivider();
                if (zone.cards.length > 0) {
                    addMenuItem('🎲 手札からランダムに1枚選ぶ', () => {
                        const randomIdx = Math.floor(Math.random() * zone.cards.length);
                        selectedCardIds = [zone.cards[randomIdx].id];
                        render();
                    });
                    addDivider();
                }
            }

            addMenuGroup('エリア操作');
            if (zone.type === 'deck' || zone.type === 'grave') {
                if (zone.type === 'deck') {
                    addMenuItem('🔀 シャッフル', () => { saveState(); zone.cards.sort(() => Math.random() - 0.5); render(); });
                    addMenuItem('🃏 指定枚数引く (手札へ)', () => drawCards(zone));
                    addMenuItem('👀 上から指定枚数を見る (めくる)', () => lookAtTopCards(zone));
                }
                addMenuItem('🔍 中身を一覧表示', () => openZoneViewerModal(zone));
                addDivider();
            }

            if (!zone.isFixed) {
                addMenuGroup('エリア管理 (カスタム)');
                addMenuItem('✎ 名称変更', () => {
                    const newName = prompt("新しいエリア名を入力してください", zone.name);
                    if (newName) { saveState(); zone.name = newName; render(); }
                });
                addMenuItem('❌ このエリアを削除', async () => {
                    if (zone.cards.length > 0) {
                        const choice = await askAB(`「${zone.name}」にはカードがあります。\nエリアごと削除しますか？`, "はい（削除する）", "いいえ（キャンセル）");
                        if (choice === 'B') return;
                    }
                    saveState();
                    zones = zones.filter(z => z.id !== zone.id);
                    render();
                });
            }
            showMenuAt(e, menu);
        }

        function showCardMenu(e, card, cEl) {
            menu.innerHTML = '';
            const isMulti = selectedCardIds.includes(card.id) && selectedCardIds.length > 1;
            const targets = isMulti ? selectedCardIds.map(id => findCardLocation(id)?.card).filter(c => c) : [card];

            // 画像拡大（裏向きでない場合、右クリックメニューに追加）
            if (!card.faceDown && !isMulti) {
                addMenuItem('🔍 画像を大きく表示', () => openPreview(card.img));
                addDivider();
            }

            if (card.faceDown && !isMulti) {
                addMenuItem('👁️ こっそり確認 (3秒間ピーピング)', () => {
                    const hadRotated = cEl.classList.contains('rotated-90');
                    cEl.classList.remove('face-down', 'rotated-90');
                    cEl.style.backgroundImage = `url(${card.img})`;
                    cEl.style.boxShadow = "0 0 15px #00ffff";
                    setTimeout(() => {
                        cEl.classList.add('face-down');
                        if (hadRotated) cEl.classList.add('rotated-90');
                        cEl.style.boxShadow = "";
                    }, 3000);
                });
                addDivider();
            }

            addMenuGroup(isMulti ? `向きの変更 (${targets.length}枚 一括)` : '向きの変更');
            addMenuItem('⬆️ 縦向き (0°)', () => { saveState(); targets.forEach(c => c.rot = 0); render(); });
            addMenuItem('➡️ 横向き (90°)', () => { saveState(); targets.forEach(c => c.rot = 90); render(); });
            addMenuItem('⬇️ 逆向き (180°)', () => { saveState(); targets.forEach(c => c.rot = 180); render(); });

            addDivider();
            addMenuGroup(isMulti ? `表裏の変更 (${targets.length}枚 一括)` : '表裏の変更');
            addMenuItem('👁️/🌚 表裏を切り替え', () => { saveState(); targets.forEach(c => c.faceDown = !c.faceDown); render(); });

            addDivider();
            addMenuGroup('特殊操作 (重ねる)');
            addMenuItem('📥 山札から指定枚数を「下」に重ねる', async () => {
                const countInput = prompt("「下」に重ねる枚数を入力してください", "1");
                const count = parseInt(countInput);
                if (!isNaN(count) && count > 0) {
                    const choice = await askAB("重ねるカードの向きを選んでください。", "裏向きで重ねる", "表向きで重ねる");
                    targets.forEach(c => applyDeckToUnder(c.id, count, choice === 'A'));
                }
            });
            addMenuItem('🔼 山札から指定枚数を「上」に重ねる', async () => {
                const countInput = prompt("「上」に重ねる枚数を入力してください", "1");
                const count = parseInt(countInput);
                if (!isNaN(count) && count > 0) {
                    const choice = await askAB("重ねるカードの向きを選んでください。", "裏向きで重ねる", "表向きで重ねる");
                    targets.forEach(c => applyDeckToTop(c.id, count, choice === 'A'));
                }
            });

            if (targets.some(c => c.topCards && c.topCards.length > 0)) {
                addMenuGroup('上に重なっているカード');
                addMenuItem('🪦 一番上のカードを外す【捨て札へ】', () => {
                    saveState();
                    targets.forEach(c => {
                        if (c.topCards && c.topCards.length > 0) {
                            const s = c.topCards.pop();
                            s.faceDown = false;
                            let g = zones.find(z => z.type === 'grave') || zones[0];
                            g.cards.unshift(s);
                        }
                    });
                    render();
                });
                addMenuItem('⏳ 一番上のカードを外す【待機エリアへ】', () => {
                    saveState();
                    targets.forEach(c => {
                        if (c.topCards && c.topCards.length > 0) {
                            const s = c.topCards.pop();
                            let w = zones.find(z => z.id === 'wait') || zones[0];
                            w.cards.push(s);
                        }
                    });
                    render();
                });
            }

            if ((card.stack && card.stack.length > 0) || (card.topCards && card.topCards.length > 0)) {
                if (!isMulti) {
                    addDivider();
                    addMenuItem(`🔍 重なっているカードを一覧表示`, () => openCardStackModal(card));
                }
            }

            addDivider();
            addMenuGroup(isMulti ? `移動 (${targets.length}枚 一括)` : '移動');
            const moveAction = (zoneId) => { isMulti ? moveSelectedCards(zoneId) : moveCardToZone(card.id, zoneId); };
            addMenuItem('🔝 山札の上へ', () => moveAction('deck'));
            addMenuItem('🪦 捨て札へ', () => moveAction('grave'));

            showMenuAt(e, menu);
        }

        function addMenuItem(text, action) {
            const item = document.createElement('div'); item.className = 'menu-item';
            item.textContent = text;
            item.onclick = () => { action(); menu.style.display = 'none'; };
            menu.appendChild(item);
        }
        function addMenuGroup(text) {
            const group = document.createElement('div'); group.className = 'menu-group';
            group.textContent = text; menu.appendChild(group);
        }
        function addDivider() {
            const div = document.createElement('div'); div.className = 'menu-divider'; menu.appendChild(div);
        }

        // --- モーダル制御 ---
        let currentModalMode = null;
        let currentViewerZone = null;
        let currentModalMainCard = null;

        // ★ モーダル内ドラッグ＆ドロップ用イベント
        modalWaitWrapper.ondragover = e => {
            if (e.dataTransfer.types.includes('application/x-modal-card-id')) e.preventDefault();
        };
        modalWaitWrapper.ondrop = async e => {
            e.preventDefault(); e.stopPropagation();
            const idStr = e.dataTransfer.getData('application/x-modal-card-id');
            if (!idStr) return;
            const cardId = parseInt(idStr);
            const idsToMove = selectedCardIds.includes(cardId) && selectedCardIds.length > 1 ? [...selectedCardIds] : [cardId];

            if (currentModalMode === 'stack' && idsToMove.includes(currentModalMainCard.id)) {
                alert("メインのカードは移動できません。");
                return;
            }
            await moveCardsToModalWait(idsToMove);
        };

        modalContent.ondragover = e => {
            if (e.dataTransfer.types.includes('application/x-modal-card-id')) e.preventDefault();
        };
        modalContent.ondrop = async e => {
            e.preventDefault(); e.stopPropagation();
            const idStr = e.dataTransfer.getData('application/x-modal-card-id');
            if (!idStr) return;
            const cardId = parseInt(idStr);
            const idsToMove = selectedCardIds.includes(cardId) && selectedCardIds.length > 1 ? [...selectedCardIds] : [cardId];

            if (currentModalMode === 'stack' && idsToMove.includes(currentModalMainCard.id)) {
                return;
            }
            await moveCardsToModalMain(idsToMove, 'bottom');
        };

        async function moveCardsToModalWait(ids) {
            saveState();
            let cards = extractCardsFromModalContext(ids);
            selectedCardIds = selectedCardIds.filter(id => !ids.includes(id));
            cards = await processStackedCards(cards);
            cards.forEach(c => modalWaitCards.push(c));
            updateModalView();
        }

        async function moveCardsToModalMain(ids, position = 'bottom') {
            saveState();
            let cards = extractCardsFromModalContext(ids);
            selectedCardIds = selectedCardIds.filter(id => !ids.includes(id));
            cards = await processStackedCards(cards);

            if (currentModalMode === 'zone' || currentModalMode === 'peek') {
                cards.forEach(c => {
                    if (currentViewerZone.type === 'deck') c.faceDown = true;
                    else if (currentViewerZone.type === 'grave') c.faceDown = false;
                });
                if (position === 'top') currentViewerZone.cards.unshift(...cards);
                else currentViewerZone.cards.push(...cards);
            } else if (currentModalMode === 'stack') {
                if (position === 'top') currentModalMainCard.topCards.push(...cards);
                else currentModalMainCard.stack.push(...cards);
            }
            updateModalView();
            render();
        }

        function closeModal() {
            if (modalWaitCards.length > 0) {
                if ((currentModalMode === 'zone' || currentModalMode === 'peek') && currentViewerZone) {
                    currentViewerZone.cards.unshift(...modalWaitCards);
                } else {
                    let w = zones.find(z => z.id === 'wait') || zones[0];
                    w.cards.push(...modalWaitCards);
                }
                modalWaitCards = [];
            }
            modalOverlay.style.display = 'none';
            currentModalMode = null;
            currentModalMainCard = null;
            currentViewerZone = null;
            selectedCardIds = [];
            render();
        }

        function openModalCommon() {
            // position が reset されていれば初期位置を設定
            if (!modalOverlay.style.left || !modalOverlay.style.top) {
                modalOverlay.style.right = '20px';
                modalOverlay.style.top = '60px';
                modalOverlay.style.left = '';
            }
            modalOverlay.style.display = 'flex';
            // ヘッダーバーをつかんでドラッグ移動
            const headerBar = document.getElementById('modal-header-bar');
            headerBar._dragHandler && headerBar.removeEventListener('mousedown', headerBar._dragHandler);
            let startX, startY, origLeft, origTop;
            const onMove = (e) => {
                const nx = origLeft + (e.clientX - startX);
                const ny = origTop + (e.clientY - startY);
                modalOverlay.style.left = Math.max(0, Math.min(window.innerWidth - modalOverlay.offsetWidth, nx)) + 'px';
                modalOverlay.style.top = Math.max(0, Math.min(window.innerHeight - 60, ny)) + 'px';
                modalOverlay.style.right = 'auto';
            };
            const onUp = () => {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
                headerBar.style.cursor = 'grab';
            };
            headerBar._dragHandler = (e) => {
                if (e.target.id === 'modal-close-x') return;
                startX = e.clientX; startY = e.clientY;
                const rect = modalOverlay.getBoundingClientRect();
                origLeft = rect.left; origTop = rect.top;
                modalOverlay.style.left = origLeft + 'px';
                modalOverlay.style.top = origTop + 'px';
                modalOverlay.style.right = 'auto';
                headerBar.style.cursor = 'grabbing';
                document.addEventListener('mousemove', onMove);
                document.addEventListener('mouseup', onUp);
            };
            headerBar.addEventListener('mousedown', headerBar._dragHandler);
        }

        function openCardStackModal(mainCard) {
            currentModalMode = 'stack';
            currentModalMainCard = mainCard;
            updateModalView();
            openModalCommon();
        }

        function openZoneViewerModal(zone) {
            currentModalMode = 'zone';
            currentViewerZone = zone;
            updateModalView();
            openModalCommon();
        }

        function shuffleAndClose() {
            if ((currentModalMode === 'zone' || currentModalMode === 'peek') && currentViewerZone && currentViewerZone.type === 'deck') {
                saveState();
                if (modalWaitCards.length > 0) {
                    currentViewerZone.cards.unshift(...modalWaitCards);
                    modalWaitCards = [];
                }
                currentViewerZone.cards.sort(() => Math.random() - 0.5);
                render();
            }
            closeModal();
        }

        async function moveSelectedToWaitFromModal() {
            const waitZone = zones.find(z => z.id === 'wait');
            if (!waitZone) return alert('待機エリアが見つかりません');

            saveState();
            let extracted = extractCardsFromModalContext([...selectedCardIds]);
            extracted = await processStackedCards(extracted);

            extracted.forEach(c => {
                c.rot = 0;
                // 山札等の確認中なら表向きにするが、スタック(封印等)の確認中は裏向きを維持
                if (currentModalMode === 'zone' || currentModalMode === 'peek') {
                    c.faceDown = false;
                }
                waitZone.cards.push(c);
            });
            selectedCardIds = [];
            updateModalView();
            render();
        }

        function updateModalView() {
            modalWaitWrapper.style.display = 'block';
            modalContent.innerHTML = '';
            modalWaitContent.innerHTML = '';

            if (currentModalMode === 'peek') {
                modalTitle.textContent = `${currentViewerZone.name} の上からめくったカード`;
                modalContent.style.display = 'none';
                document.getElementById('modal-divider').style.display = 'none';
                document.getElementById('modal-subtitle').textContent = '▼ めくったカード (右クリックで各エリアへ移動) ▼';
            } else {
                modalContent.style.display = 'flex';
                document.getElementById('modal-divider').style.display = 'block';
                document.getElementById('modal-subtitle').textContent = '▼ 一時待機エリア (ドラッグ＆ドロップ可能) ▼';
                if (currentModalMode === 'zone') {
                    modalTitle.textContent = `${currentViewerZone.name} の中身 (${currentViewerZone.cards.length}枚)`;
                } else if (currentModalMode === 'stack') {
                    modalTitle.textContent = "重なっているカード一覧 (黄色枠がメイン)";
                }
            }

            const createModalCard = (c, isMain, forceFaceUp = false, labelText = "", context = 'main') => {
                const cEl = document.createElement('div');
                const isSelected = selectedCardIds.includes(c.id);
                const isVisualFaceDown = forceFaceUp ? false : c.faceDown;

                let rotClass = '';
                if (isVisualFaceDown) {
                    if (currentModalMode === 'stack') rotClass = '';
                    else rotClass = 'rotated-90';
                }

                cEl.className = `card ${isSelected ? 'selected' : ''} ${isVisualFaceDown ? 'face-down' : ''} ${rotClass}`;
                // ★ モーダル内ではカードを小さく表示
                cEl.style.width = '50px';
                cEl.style.height = '70px';
                cEl.style.backgroundSize = 'cover';
                if (!isVisualFaceDown) cEl.style.backgroundImage = `url(${c.img})`;

                if (isMain) cEl.style.boxShadow = "0 0 15px #ffcc00";

                if (isSelected && !isMain) {
                    const badge = document.createElement('div');
                    badge.className = 'order-badge';
                    badge.textContent = selectedCardIds.indexOf(c.id) + 1;
                    badge.style.cssText += 'width:16px;height:16px;font-size:9px;top:-6px;left:-6px;';
                    cEl.appendChild(badge);
                }

                if (labelText) {
                    const label = document.createElement('div');
                    label.style.position = 'absolute';
                    label.style.bottom = '-18px';
                    label.style.left = '50%';
                    label.style.transform = 'translateX(-50%)';
                    label.style.width = '80px';
                    label.style.textAlign = 'center';
                    label.style.fontSize = '9px';
                    label.style.color = '#fff';
                    label.style.background = '#000';
                    label.style.padding = '1px 0';
                    label.style.borderRadius = '3px';
                    label.style.pointerEvents = 'none';
                    label.style.whiteSpace = 'nowrap';
                    label.style.overflow = 'hidden';
                    label.textContent = labelText;
                    cEl.appendChild(label);
                    cEl.style.marginBottom = '20px';
                }

                if (!isMain) {
                    cEl.draggable = true;
                    cEl.ondragstart = (e) => {
                        e.dataTransfer.setData('application/x-modal-card-id', c.id.toString());
                        e.dataTransfer.setData('application/x-modal-card-context', context);
                        e.stopPropagation();
                    };
                    // D&D並び替え用：ドラッグオーバーでハイライト
                    cEl.ondragover = (e) => {
                        if (e.dataTransfer.types.includes('application/x-modal-card-id')) {
                            e.preventDefault();
                            cEl.style.outline = '2px solid #0078d7';
                        }
                    };
                    cEl.ondragleave = () => { cEl.style.outline = ''; };
                    cEl.ondrop = (e) => {
                        e.preventDefault(); e.stopPropagation();
                        cEl.style.outline = '';
                        const srcId = parseInt(e.dataTransfer.getData('application/x-modal-card-id'));
                        const srcCtx = e.dataTransfer.getData('application/x-modal-card-context');
                        if (isNaN(srcId) || srcId === c.id || srcCtx !== context) return;
                        saveState();
                        // contextに応じてリストを取得して並び替え
                        let list;
                        if (context === 'main') list = currentModalMode === 'zone' ? currentViewerZone.cards : null;
                        else if (context === 'wait') list = modalWaitCards;
                        if (!list) return;
                        const fromIdx = list.findIndex(x => x.id === srcId);
                        const toIdx = list.findIndex(x => x.id === c.id);
                        if (fromIdx === -1 || toIdx === -1) return;
                        const [moved] = list.splice(fromIdx, 1);
                        list.splice(toIdx, 0, moved);
                        updateModalView();
                        render();
                    };
                }

                cEl.onclick = (e) => {
                    e.stopPropagation();
                    if (isMain) return alert("メインのカードは一覧からは直接移動できません。\n盤面から移動させてください。");
                    const idx = selectedCardIds.indexOf(c.id);
                    if (idx === -1) { selectedCardIds.push(c.id); }
                    else { selectedCardIds.splice(idx, 1); }
                    updateModalView();
                    render();
                };

                cEl.oncontextmenu = (e) => {
                    e.stopPropagation(); e.preventDefault();
                    if (isMain) {
                        // メインカードも右クリックで画像拡大できる
                        if (!isVisualFaceDown) openPreview(c.img);
                        return;
                    }
                    showModalExtractMenu(e, c, cEl, isVisualFaceDown ? null : c.img);
                };
                return cEl;
            };

            if (currentModalMode === 'zone') {
                currentViewerZone.cards.forEach(c => modalContent.appendChild(createModalCard(c, false, true, '', 'main')));
            } else if (currentModalMode === 'stack') {
                if (currentModalMainCard.topCards) {
                    const tops = [...currentModalMainCard.topCards].reverse();
                    tops.forEach((c, i) => modalContent.appendChild(createModalCard(c, false, false, `上: ${i + 1}枚目${i === 0 ? ' (一番上)' : ''}`, 'main')));
                }
                modalContent.appendChild(createModalCard(currentModalMainCard, true, false, "メイン", 'main'));
                if (currentModalMainCard.stack) {
                    currentModalMainCard.stack.forEach((c, i) => modalContent.appendChild(createModalCard(c, false, false, `下: ${i + 1}枚目`, 'main')));
                }
            }

            // ★ 一時待機エリアの描画時、スタック表示モードの場合は forceFaceUp を false (元の表裏を維持) にする
            const forceWaitFaceUp = (currentModalMode === 'zone' && currentViewerZone && currentViewerZone.type === 'deck') || currentModalMode === 'peek';
            modalWaitCards.forEach(c => {
                modalWaitContent.appendChild(createModalCard(c, false, forceWaitFaceUp, '', 'wait'));
            });

            const selectedCount = selectedCardIds.length;
            let buttonsHtml = `<button class="btn-modal" onclick="closeModal()">閉じる</button>`;
            if ((currentModalMode === 'zone' || currentModalMode === 'peek') && currentViewerZone.type === 'deck') {
                const btnText = currentModalMode === 'peek' ? '🔀 残りを戻してシャッフル' : '🔀 シャッフルして閉じる';
                buttonsHtml += `<button class="btn-modal btn-modal-primary" onclick="shuffleAndClose()">${btnText}</button>`;
            }
            if (selectedCount > 0) {
                buttonsHtml += `<button class="btn-modal btn-modal-success" onclick="moveSelectedToWaitFromModal()">📥 選択中の ${selectedCount} 枚を盤面の待機エリアへ</button>`;
            }
            modalButtons.innerHTML = buttonsHtml;

            // ★ 盤面の各エリアへのD&Dドロップゾーンを表示
            renderModalFieldZones();
        }

        let modalFieldZonesCollapsed = false;

        function renderModalFieldZones() {
            const fieldZonesDiv = document.getElementById('modal-field-zones');
            const divider2 = document.getElementById('modal-divider2');
            fieldZonesDiv.innerHTML = '';
            divider2.style.display = 'block';
            fieldZonesDiv.style.display = 'block';

            const label = document.createElement('div');
            label.style.cssText = 'width:100%; font-size:11px; color:#aaa; font-weight:bold; background:#2a2a2a; padding:5px 8px; box-sizing:border-box; cursor:pointer; display:flex; justify-content:space-between; align-items:center; border-radius:4px; user-select:none; margin-bottom:4px;';
            label.innerHTML = '<span>' + (modalFieldZonesCollapsed ? '▶' : '▼') + ' 盤面エリアへ直接D&Dで移動できます</span>' +
                '<span style="font-size:10px;color:#888;">' + (modalFieldZonesCollapsed ? '▼ 展開' : '▲ 最小化') + '</span>';
            fieldZonesDiv.appendChild(label);

            const grid = document.createElement('div');
            grid.style.cssText = 'display:' + (modalFieldZonesCollapsed ? 'none' : 'flex') + '; flex-wrap:wrap; gap:6px; width:100%; padding:4px 0;';

            label.onclick = () => {
                modalFieldZonesCollapsed = !modalFieldZonesCollapsed;
                renderModalFieldZones();
            };

            zones.forEach(z => {
                const zBtn = document.createElement('div');
                zBtn.style.cssText = `
                    background: rgba(255,255,255,0.06);
                    border: 2px dashed #666;
                    border-radius: 6px;
                    padding: 6px 10px;
                    min-width: 90px;
                    flex: 1;
                    cursor: pointer;
                    font-size: 12px;
                    color: #ccc;
                    text-align: center;
                    transition: background 0.15s, border-color 0.15s;
                `;
                zBtn.textContent = `${z.name} (${z.cards.length}枚)`;

                zBtn.ondragover = (e) => {
                    if (e.dataTransfer.types.includes('application/x-modal-card-id')) {
                        e.preventDefault();
                        zBtn.style.background = 'rgba(0,120,215,0.35)';
                        zBtn.style.borderColor = '#0078d7';
                    }
                };
                zBtn.ondragleave = () => {
                    zBtn.style.background = 'rgba(255,255,255,0.06)';
                    zBtn.style.borderColor = '#666';
                };
                zBtn.ondrop = async (e) => {
                    e.preventDefault(); e.stopPropagation();
                    zBtn.style.background = 'rgba(255,255,255,0.06)';
                    zBtn.style.borderColor = '#666';
                    const idStr = e.dataTransfer.getData('application/x-modal-card-id');
                    if (!idStr) return;
                    const cardId = parseInt(idStr);
                    const idsToMove = selectedCardIds.includes(cardId) && selectedCardIds.length > 1 ? [...selectedCardIds] : [cardId];
                    if (currentModalMode === 'stack' && idsToMove.includes(currentModalMainCard.id)) {
                        alert("メインのカードは直接移動できません。");
                        return;
                    }
                    await moveModalCardsToFieldZone(idsToMove, z.id);
                };

                grid.appendChild(zBtn);
            });
            fieldZonesDiv.appendChild(grid);
        }

        async function moveModalCardsToFieldZone(ids, targetZoneId) {
            saveState();
            const idsToExtract = [...ids];
            let cards = extractCardsFromModalContext(idsToExtract);
            selectedCardIds = selectedCardIds.filter(id => !idsToExtract.includes(id));
            cards = await processStackedCards(cards);

            const targetZone = zones.find(z => z.id === targetZoneId);
            if (!targetZone) return;

            cards.forEach(c => {
                c.rot = 0;
                if (targetZone.type === 'deck') c.faceDown = true;
                else if (targetZone.type === 'grave') c.faceDown = false;
                else if (targetZone.id === 'hand') c.faceDown = false;
                else if (currentModalMode === 'zone' || currentModalMode === 'peek') c.faceDown = false;
                targetZone.cards.push(c);
            });
            updateModalView();
            render();
        }

        function extractCardsFromModalContext(idsToExtract) {
            let extracted = [];
            idsToExtract.forEach(id => {
                let idx = modalWaitCards.findIndex(c => c.id === id);
                if (idx !== -1) { extracted.push(modalWaitCards.splice(idx, 1)[0]); return; }

                if (currentModalMode === 'zone') {
                    idx = currentViewerZone.cards.findIndex(c => c.id === id);
                    if (idx !== -1) { extracted.push(currentViewerZone.cards.splice(idx, 1)[0]); return; }
                } else if (currentModalMode === 'stack') {
                    idx = currentModalMainCard.topCards.findIndex(c => c.id === id);
                    if (idx !== -1) { extracted.push(currentModalMainCard.topCards.splice(idx, 1)[0]); return; }
                    idx = currentModalMainCard.stack.findIndex(c => c.id === id);
                    if (idx !== -1) { extracted.push(currentModalMainCard.stack.splice(idx, 1)[0]); return; }
                }
            });
            return extracted;
        }

        function showModalExtractMenu(e, clickedCard, cEl, imgSrc = null) {
            menu.innerHTML = '';
            const isMulti = selectedCardIds.includes(clickedCard.id) && selectedCardIds.length > 1;
            const countText = isMulti ? `${selectedCardIds.length}枚を一括で` : 'このカードを';

            // 画像拡大（表向きで imgSrc がある場合）
            if (imgSrc && !isMulti) {
                addMenuItem('🔍 画像を大きく表示', () => openPreview(imgSrc));
                addDivider();
            }

            if (clickedCard.faceDown && !isMulti && currentModalMode !== 'peek' && currentModalMode !== 'zone') {
                addMenuItem('👁️ こっそり確認 (3秒間ピーピング)', () => {
                    const hadRotated = cEl.classList.contains('rotated-90');
                    cEl.classList.remove('face-down', 'rotated-90');
                    cEl.style.backgroundImage = `url(${clickedCard.img})`;
                    cEl.style.boxShadow = "0 0 15px #00ffff";
                    setTimeout(() => {
                        cEl.classList.add('face-down');
                        if (hadRotated) cEl.classList.add('rotated-90');
                        cEl.style.boxShadow = "";
                    }, 3000);
                });
                addDivider();
            }

            addMenuGroup(`${countText}移動`);

            const moveToZone = async (targetZoneId, position = 'bottom') => {
                saveState();
                const idsToExtract = isMulti ? [...selectedCardIds] : [clickedCard.id];
                let cards = extractCardsFromModalContext(idsToExtract);
                selectedCardIds = selectedCardIds.filter(id => !idsToExtract.includes(id));

                cards = await processStackedCards(cards);

                const targetZone = zones.find(z => z.id === targetZoneId);
                if (!targetZone) return;

                cards.forEach(c => {
                    c.rot = 0;
                    if (targetZone.type === 'deck') c.faceDown = true;
                    else if (targetZone.type === 'grave') c.faceDown = false;
                    else if (targetZone.id === 'hand') c.faceDown = false;
                    else {
                        // ★ 山札などからの移動時は表向き、スタックからの移動は元の向きを維持
                        if (currentModalMode === 'zone' || currentModalMode === 'peek') {
                            c.faceDown = false;
                        }
                    }

                    if (position === 'top') targetZone.cards.unshift(c);
                    else targetZone.cards.push(c);
                });
                updateModalView();
                render();
            };

            const moveToModalWait = async () => {
                saveState();
                const idsToExtract = isMulti ? [...selectedCardIds] : [clickedCard.id];
                let cards = extractCardsFromModalContext(idsToExtract);
                selectedCardIds = selectedCardIds.filter(id => !idsToExtract.includes(id));
                cards = await processStackedCards(cards);
                cards.forEach(c => modalWaitCards.push(c));
                updateModalView();
            };

            const moveToModalZone = async (position) => {
                saveState();
                const idsToExtract = isMulti ? [...selectedCardIds] : [clickedCard.id];
                let cards = extractCardsFromModalContext(idsToExtract);
                selectedCardIds = selectedCardIds.filter(id => !idsToExtract.includes(id));
                cards = await processStackedCards(cards);

                if (currentModalMode === 'zone' || currentModalMode === 'peek') {
                    cards.forEach(c => {
                        if (currentViewerZone.type === 'deck') c.faceDown = true;
                        else if (currentViewerZone.type === 'grave') c.faceDown = false;
                    });
                    if (position === 'top') currentViewerZone.cards.unshift(...cards);
                    else currentViewerZone.cards.push(...cards);
                } else if (currentModalMode === 'stack') {
                    if (position === 'top') currentModalMainCard.topCards.push(...cards);
                    else currentModalMainCard.stack.push(...cards);
                }
                updateModalView();
                render();
            };

            if (currentModalMode === 'peek') {
                addMenuItem('🔝 山札(元の場所)の一番上へ戻す', () => moveToModalZone('top'));
                addMenuItem('⬇️ 山札(元の場所)の一番下へ送る', () => moveToModalZone('bottom'));
            } else {
                const isFromWait = modalWaitCards.some(c => c.id === clickedCard.id);
                if (!isFromWait) {
                    addMenuItem('👇 モーダル内の一時待機エリアへ送る', () => moveToModalWait());
                    addDivider();
                    addMenuItem('🔝 今の場所の一番上へ', () => moveToModalZone('top'));
                    addMenuItem('⬇️ 今の場所の一番下へ', () => moveToModalZone('bottom'));
                } else {
                    addMenuItem('🔝 元の場所の一番上へ戻す', () => moveToModalZone('top'));
                    addMenuItem('⬇️ 元の場所の一番下へ戻す', () => moveToModalZone('bottom'));
                }
            }

            addDivider();
            addMenuGroup('盤面の各エリアへ移動');
            zones.forEach(z => {
                if (currentModalMode !== 'zone' || z.id !== currentViewerZone.id) {
                    addMenuItem(`➡️ ${z.name}へ`, () => moveToZone(z.id, 'bottom'));
                }
            });

            showMenuAt(e, menu);
        }

        function updateCardScale(val) {
            document.documentElement.style.setProperty('--card-w', Math.floor(70 * val) + 'px');
            document.documentElement.style.setProperty('--card-h', Math.floor(100 * val) + 'px');
        }

        document.getElementById('loader').onchange = e => {
            pool = [];
            const files = [...e.target.files];
            files.forEach(f => {
                const reader = new FileReader();
                reader.onload = ev => pool.push(ev.target.result);
                reader.readAsDataURL(f);
            });
            alert(`${files.length}枚の画像を読み込みました。`);
        };

        function initGame() {
            if (pool.length === 0) return alert('先に画像を読み込んでください。');
            saveState();
            const deckZone = zones.find(z => z.type === 'deck');
            if (!deckZone) return alert('山札ゾーンがありません！');
            zones.forEach(z => z.cards = []);
            const deck = pool.map(img => createCard(img));
            deck.sort(() => Math.random() - 0.5);
            deckZone.cards = deck;
            selectedCardIds = [];
            modalWaitCards = [];
            render();
        }

        window.onclick = e => {
            if (!e.target.closest('#context-menu') && !e.target.closest('#modal-overlay') && !e.target.closest('#dialog-overlay')) {
                menu.style.display = 'none';
            }
            if (!e.target.closest('.card') && !e.target.closest('#context-menu') && !e.target.closest('#toolbar') && !e.target.closest('#modal-overlay') && !e.target.closest('#preview-overlay') && !e.target.closest('#dialog-overlay') && !e.target.closest('.resizer')) {
                clearSelection();
            }
        };

        let activeResizer = null;
        let startY = 0;
        let startPrevH = 0;
        let startNextH = 0;

        document.querySelectorAll('.resizer').forEach(resizer => {
            resizer.addEventListener('mousedown', e => {
                activeResizer = resizer;
                startY = e.clientY;
                const prev = resizer.previousElementSibling;
                const next = resizer.nextElementSibling;
                startPrevH = prev.getBoundingClientRect().height;
                startNextH = next.getBoundingClientRect().height;
                resizer.classList.add('dragging');
                document.body.style.cursor = 'row-resize';
                e.preventDefault();
            });
        });

        document.addEventListener('mousemove', e => {
            if (!activeResizer) return;
            const dy = e.clientY - startY;
            const prev = activeResizer.previousElementSibling;
            const next = activeResizer.nextElementSibling;
            const newPrevH = Math.max(60, startPrevH + dy);
            const newNextH = Math.max(60, startNextH - dy);
            
            if (newPrevH > 60 && newNextH > 60) {
                prev.style.flex = `0 0 ${newPrevH}px`;
                next.style.flex = `0 0 ${newNextH}px`;
            } else {
                const total = startPrevH + startNextH;
                if (newPrevH <= 60) {
                    prev.style.flex = `0 0 60px`;
                    next.style.flex = `0 0 ${total - 60}px`;
                } else if (newNextH <= 60) {
                    next.style.flex = `0 0 60px`;
                    prev.style.flex = `0 0 ${total - 60}px`;
                }
            }
        });

        document.addEventListener('mouseup', () => {
            if (activeResizer) {
                activeResizer.classList.remove('dragging');
                activeResizer = null;
                document.body.style.cursor = '';
            }
        });

        render();